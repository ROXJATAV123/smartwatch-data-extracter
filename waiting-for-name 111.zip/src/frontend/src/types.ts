// ─── Bluetooth Types ───────────────────────────────────────────────────────────

export interface BluetoothDeviceInfo {
  id: string;
  name: string;
  rssi: number | null;
  serviceUuids: string[];
  connected: boolean;
}

export interface GattCharacteristic {
  uuid: string;
  properties: string[];
  rawValue: Uint8Array | null;
}

export interface GattService {
  uuid: string;
  characteristics: GattCharacteristic[];
}

export interface StreamEntry {
  timestamp: number;
  serviceUuid: string;
  characteristicUuid: string;
  rawValue: Uint8Array;
}

// ─── GPS Types ─────────────────────────────────────────────────────────────────

export interface LocationPoint {
  lat: number;
  lng: number;
  accuracy: number;
  altitude: number | null;
  speed: number | null;
  heading: number | null;
  timestamp: number;
}

// ─── Hex Dump Types ─────────────────────────────────────────────────────────────

export interface HexDumpRow {
  offset: number;
  bytes: number[];
  hex: string[];
  decimal: number[];
  binary: string[];
}

// ─── File Upload Types ──────────────────────────────────────────────────────────

export interface UploadedFileSnapshot {
  name: string;
  size: number;
  type: string;
  lastModified: number;
  detectedType: string;
  imageWidth?: number;
  imageHeight?: number;
  previewBytes: number[];
}

// ─── Sensor Snapshot Types (for export) ─────────────────────────────────────────

export interface SensorSnapshot {
  // no change needed — FitnessSnapshot lives in fitness-store.ts

  capturedAt: string;
  motion: {
    acceleration: { x: number | null; y: number | null; z: number | null };
    accelerationIncludingGravity: {
      x: number | null;
      y: number | null;
      z: number | null;
    };
    rotationRate: {
      alpha: number | null;
      beta: number | null;
      gamma: number | null;
    };
    interval: number | null;
  } | null;
  orientation: {
    alpha: number | null;
    beta: number | null;
    gamma: number | null;
    absolute: boolean;
  } | null;
  battery: {
    charging: boolean;
    chargingTime: number;
    dischargingTime: number;
    level: number;
  } | null;
  network: {
    type: string;
    effectiveType: string;
    downlink: number;
    rtt: number;
    saveData: boolean;
  } | null;
  screen: {
    width: number;
    height: number;
    colorDepth: number;
    pixelDepth: number;
    orientationType: string;
    orientationAngle: number;
    devicePixelRatio: number;
  } | null;
  deviceInfo: {
    userAgent: string;
    platform: string;
    language: string;
    hardwareConcurrency: number;
    deviceMemory: number | null;
    maxTouchPoints: number;
  } | null;
}
