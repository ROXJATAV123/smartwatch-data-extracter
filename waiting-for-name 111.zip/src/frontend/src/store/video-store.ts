import { create } from "zustand";
interface VideoState {
  entries: never[];
}
export const useVideoStore = create<VideoState>(() => ({ entries: [] }));
