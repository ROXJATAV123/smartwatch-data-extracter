import { create } from "zustand";

export interface FileUploadState {
  name: string | null;
  size: number | null;
  type: string | null;
  lastModified: number | null;
  detectedType: string | null;
  imageWidth?: number;
  imageHeight?: number;
  previewBytes: number[] | null; // hex-friendly array
  setFileData: (
    data: Omit<FileUploadState, "setFileData" | "clearFileData">,
  ) => void;
  clearFileData: () => void;
}

export const useFileStore = create<FileUploadState>((set) => ({
  name: null,
  size: null,
  type: null,
  lastModified: null,
  detectedType: null,
  imageWidth: undefined,
  imageHeight: undefined,
  previewBytes: null,
  setFileData: (data) => set(data),
  clearFileData: () =>
    set({
      name: null,
      size: null,
      type: null,
      lastModified: null,
      detectedType: null,
      imageWidth: undefined,
      imageHeight: undefined,
      previewBytes: null,
    }),
}));
