import type {
  BatteryData,
  CscData,
  HeartRateData,
  RscData,
} from "@/utils/gatt-decoders";
import {
  parseBatteryLevel,
  parseBodySensorLocation,
  parseCscMeasurement,
  parseDeviceInfoString,
  parseHeartRate,
  parseRscMeasurement,
} from "@/utils/gatt-decoders";
import { create } from "zustand";

// ─── GATT UUID Constants ───────────────────────────────────────────────────────

export const UUIDS = {
  // Services
  HEART_RATE_SVC: "0000180d-0000-1000-8000-00805f9b34fb",
  BATTERY_SVC: "0000180f-0000-1000-8000-00805f9b34fb",
  DEVICE_INFO_SVC: "0000180a-0000-1000-8000-00805f9b34fb",
  RSC_SVC: "00001814-0000-1000-8000-00805f9b34fb",
  CSC_SVC: "00001816-0000-1000-8000-00805f9b34fb",
  // Characteristics
  HEART_RATE_MEAS: "00002a37-0000-1000-8000-00805f9b34fb",
  BODY_SENSOR_LOC: "00002a38-0000-1000-8000-00805f9b34fb",
  BATTERY_LEVEL: "00002a19-0000-1000-8000-00805f9b34fb",
  MANUFACTURER_NAME: "00002a29-0000-1000-8000-00805f9b34fb",
  MODEL_NUMBER: "00002a24-0000-1000-8000-00805f9b34fb",
  FIRMWARE_REV: "00002a26-0000-1000-8000-00805f9b34fb",
  HARDWARE_REV: "00002a27-0000-1000-8000-00805f9b34fb",
  RSC_MEAS: "00002a53-0000-1000-8000-00805f9b34fb",
  CSC_MEAS: "00002a5b-0000-1000-8000-00805f9b34fb",
} as const;

// ─── Snapshot types ────────────────────────────────────────────────────────────

export interface FitnessCharSnapshot {
  /** Latest parsed value — varies by characteristic */
  parsed: HeartRateData | RscData | CscData | BatteryData | string | null;
  /** Raw bytes of the last received value */
  rawBytes: number[] | null;
  /** Timestamp of last update */
  updatedAt: number | null;
  /** Error string if parsing failed or characteristic unavailable */
  error: string | null;
}

export interface FitnessSnapshot {
  heartRate: FitnessCharSnapshot;
  bodySensorLocation: FitnessCharSnapshot;
  battery: FitnessCharSnapshot;
  manufacturerName: FitnessCharSnapshot;
  modelNumber: FitnessCharSnapshot;
  firmwareRevision: FitnessCharSnapshot;
  hardwareRevision: FitnessCharSnapshot;
  rscMeasurement: FitnessCharSnapshot;
  cscMeasurement: FitnessCharSnapshot;
}

type SnapshotKey = keyof FitnessSnapshot;

const emptyChar = (): FitnessCharSnapshot => ({
  parsed: null,
  rawBytes: null,
  updatedAt: null,
  error: null,
});

const initialSnapshot = (): FitnessSnapshot => ({
  heartRate: emptyChar(),
  bodySensorLocation: emptyChar(),
  battery: emptyChar(),
  manufacturerName: emptyChar(),
  modelNumber: emptyChar(),
  firmwareRevision: emptyChar(),
  hardwareRevision: emptyChar(),
  rscMeasurement: emptyChar(),
  cscMeasurement: emptyChar(),
});

// ─── Store ─────────────────────────────────────────────────────────────────────

interface FitnessState {
  snapshot: FitnessSnapshot;
  isLoadingMetrics: boolean;
  loadError: string | null;
}

interface FitnessActions {
  /** Called by FitnessPage after BT connection — reads all readable chars & starts notifications */
  loadMetrics: (gattServer: GattServerRef) => Promise<void>;
  /** Update a single snapshot entry from a DataView (used by notification handler) */
  updateFromDataView: (
    key: SnapshotKey,
    dv: DataView,
    rawBytes: Uint8Array,
  ) => void;
  /** Mark a characteristic as Not Available with a reason */
  markUnavailable: (key: SnapshotKey, reason: string) => void;
  reset: () => void;
}

// Minimal GATT server ref — mirrors what bluetooth-store exposes
export interface GattServerRef {
  getPrimaryService(uuid: string): Promise<GattSvcRef>;
}
export interface GattSvcRef {
  getCharacteristic(uuid: string): Promise<GattCharRef>;
  getCharacteristics(): Promise<GattCharRef[]>;
}
export interface GattCharRef {
  uuid: string;
  properties: Record<string, boolean>;
  readValue(): Promise<DataView>;
  startNotifications(): Promise<GattCharRef>;
  addEventListener(
    event: string,
    handler: (e: { target: { value: DataView } }) => void,
  ): void;
  removeEventListener(
    event: string,
    handler: (e: { target: { value: DataView } }) => void,
  ): void;
}

// Active notification cleanup refs
const _fitnessNotifyHandlers = new Map<
  string,
  (e: { target: { value: DataView } }) => void
>();
const _fitnessNotifyChars = new Map<string, GattCharRef>();

function stopAllFitnessNotifications() {
  for (const [uuid, handler] of _fitnessNotifyHandlers.entries()) {
    const ch = _fitnessNotifyChars.get(uuid);
    if (ch) {
      try {
        ch.removeEventListener("characteristicvaluechanged", handler);
      } catch {
        /* ignore */
      }
    }
  }
  _fitnessNotifyHandlers.clear();
  _fitnessNotifyChars.clear();
}

export const useFitnessStore = create<FitnessState & FitnessActions>(
  (set, get) => ({
    snapshot: initialSnapshot(),
    isLoadingMetrics: false,
    loadError: null,

    reset: () => {
      stopAllFitnessNotifications();
      set({
        snapshot: initialSnapshot(),
        isLoadingMetrics: false,
        loadError: null,
      });
    },

    markUnavailable: (key, reason) => {
      set((s) => ({
        snapshot: {
          ...s.snapshot,
          [key]: {
            parsed: null,
            rawBytes: null,
            updatedAt: null,
            error: reason,
          },
        },
      }));
    },

    updateFromDataView: (key, dv, rawBytes) => {
      const bytes = Array.from(rawBytes);
      let parsed: FitnessCharSnapshot["parsed"] = null;
      switch (key) {
        case "heartRate":
          parsed = parseHeartRate(dv);
          break;
        case "bodySensorLocation":
          parsed = parseBodySensorLocation(dv);
          break;
        case "battery":
          parsed = parseBatteryLevel(dv);
          break;
        case "manufacturerName":
          parsed = parseDeviceInfoString(dv);
          break;
        case "modelNumber":
          parsed = parseDeviceInfoString(dv);
          break;
        case "firmwareRevision":
          parsed = parseDeviceInfoString(dv);
          break;
        case "hardwareRevision":
          parsed = parseDeviceInfoString(dv);
          break;
        case "rscMeasurement":
          parsed = parseRscMeasurement(dv);
          break;
        case "cscMeasurement":
          parsed = parseCscMeasurement(dv);
          break;
      }
      set((s) => ({
        snapshot: {
          ...s.snapshot,
          [key]: {
            parsed,
            rawBytes: bytes,
            updatedAt: Date.now(),
            error: null,
          },
        },
      }));
    },

    loadMetrics: async (gattServer) => {
      stopAllFitnessNotifications();
      set({
        isLoadingMetrics: true,
        loadError: null,
        snapshot: initialSnapshot(),
      });

      const { updateFromDataView, markUnavailable } = get();

      async function tryReadChar(
        key: SnapshotKey,
        serviceUuid: string,
        charUuid: string,
      ): Promise<GattCharRef | null> {
        try {
          const svc = await gattServer.getPrimaryService(serviceUuid);
          const ch = await svc.getCharacteristic(charUuid);
          if (ch.properties.read) {
            const dv = await ch.readValue();
            updateFromDataView(key, dv, new Uint8Array(dv.buffer));
          }
          return ch;
        } catch {
          return null;
        }
      }

      async function trySubscribeChar(
        key: SnapshotKey,
        serviceUuid: string,
        charUuid: string,
      ) {
        try {
          const svc = await gattServer.getPrimaryService(serviceUuid);
          const ch = await svc.getCharacteristic(charUuid);
          const notifyChar = await ch.startNotifications();
          const handler = (e: { target: { value: DataView } }) => {
            const raw = new Uint8Array(e.target.value.buffer);
            updateFromDataView(key, e.target.value, raw);
          };
          notifyChar.addEventListener("characteristicvaluechanged", handler);
          _fitnessNotifyHandlers.set(charUuid, handler);
          _fitnessNotifyChars.set(charUuid, notifyChar);
        } catch {
          markUnavailable(
            key,
            "Device does not support notifications for this characteristic",
          );
        }
      }

      // ── Heart Rate ──────────────────────────────────────────────────────────────
      const hrChar = await tryReadChar(
        "heartRate",
        UUIDS.HEART_RATE_SVC,
        UUIDS.HEART_RATE_MEAS,
      );
      if (hrChar) {
        if (hrChar.properties.notify || hrChar.properties.indicate) {
          await trySubscribeChar(
            "heartRate",
            UUIDS.HEART_RATE_SVC,
            UUIDS.HEART_RATE_MEAS,
          );
        }
      } else {
        markUnavailable(
          "heartRate",
          "Device does not advertise Heart Rate Service (0x180D)",
        );
      }

      // ── Body Sensor Location ────────────────────────────────────────────────────
      const bslResult = await tryReadChar(
        "bodySensorLocation",
        UUIDS.HEART_RATE_SVC,
        UUIDS.BODY_SENSOR_LOC,
      );
      if (!bslResult) {
        markUnavailable(
          "bodySensorLocation",
          "Body Sensor Location not reported by this device",
        );
      }

      // ── Battery ─────────────────────────────────────────────────────────────────
      const batChar = await tryReadChar(
        "battery",
        UUIDS.BATTERY_SVC,
        UUIDS.BATTERY_LEVEL,
      );
      if (batChar) {
        if (batChar.properties.notify) {
          await trySubscribeChar(
            "battery",
            UUIDS.BATTERY_SVC,
            UUIDS.BATTERY_LEVEL,
          );
        }
      } else {
        markUnavailable(
          "battery",
          "Device does not expose Battery Service (0x180F)",
        );
      }

      // ── Device Information ──────────────────────────────────────────────────────
      (await tryReadChar(
        "manufacturerName",
        UUIDS.DEVICE_INFO_SVC,
        UUIDS.MANUFACTURER_NAME,
      )) ??
        markUnavailable("manufacturerName", "Manufacturer Name not available");
      (await tryReadChar(
        "modelNumber",
        UUIDS.DEVICE_INFO_SVC,
        UUIDS.MODEL_NUMBER,
      )) ?? markUnavailable("modelNumber", "Model Number not available");
      (await tryReadChar(
        "firmwareRevision",
        UUIDS.DEVICE_INFO_SVC,
        UUIDS.FIRMWARE_REV,
      )) ??
        markUnavailable("firmwareRevision", "Firmware Revision not available");
      (await tryReadChar(
        "hardwareRevision",
        UUIDS.DEVICE_INFO_SVC,
        UUIDS.HARDWARE_REV,
      )) ??
        markUnavailable("hardwareRevision", "Hardware Revision not available");

      // ── RSC (Running Speed & Cadence) — notify-only per BLE spec (0x2A53) ────────
      await trySubscribeChar("rscMeasurement", UUIDS.RSC_SVC, UUIDS.RSC_MEAS);

      // ── CSC (Cycling Speed & Cadence) — notify-only per BLE spec (0x2A5B) ─────────
      await trySubscribeChar("cscMeasurement", UUIDS.CSC_SVC, UUIDS.CSC_MEAS);

      set({ isLoadingMetrics: false });
    },
  }),
);
