import { create } from "zustand";
interface MessagesState {
  entries: never[];
}
export const useMessagesStore = create<MessagesState>(() => ({ entries: [] }));
