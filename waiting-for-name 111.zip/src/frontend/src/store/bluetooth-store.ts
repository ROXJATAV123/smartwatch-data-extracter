import type { BluetoothDeviceInfo, GattService, StreamEntry } from "@/types";
import { create } from "zustand";

// Web Bluetooth API shimmed types (not in all TS lib.dom.d.ts versions)
type BtNavigator = Navigator & {
  bluetooth: {
    requestDevice(options: Record<string, unknown>): Promise<BtDevice>;
  };
};
type BtDevice = {
  id: string;
  name?: string;
  gatt?: BtGattServer;
  addEventListener(event: string, handler: () => void): void;
};
type BtGattServer = {
  connected: boolean;
  connect(): Promise<BtGattServer>;
  disconnect(): void;
  getPrimaryServices(): Promise<BtService[]>;
  getPrimaryService(uuid: string): Promise<BtService>;
};
type BtService = {
  uuid: string;
  getCharacteristics(): Promise<BtCharacteristic[]>;
  getCharacteristic(uuid: string): Promise<BtCharacteristic>;
};
type BtCharacteristic = {
  uuid: string;
  properties: Record<string, boolean>;
  readValue(): Promise<DataView>;
  startNotifications(): Promise<BtCharacteristic>;
  stopNotifications(): Promise<BtCharacteristic>;
  addEventListener(
    event: string,
    handler: (e: { target: { value: DataView } }) => void,
  ): void;
  removeEventListener(
    event: string,
    handler: (e: { target: { value: DataView } }) => void,
  ): void;
};

// Maps characteristic UUID → active BtCharacteristic reference for notifications
const _notifyHandlers = new Map<
  string,
  (e: { target: { value: DataView } }) => void
>();
const _notifyChars = new Map<string, BtCharacteristic>();

export type ConnectionStatus = "disconnected" | "connecting" | "connected";

interface BluetoothState {
  devices: BluetoothDeviceInfo[];
  activeDevice: BluetoothDeviceInfo | null;
  services: GattService[];
  isScanning: boolean;
  connectionStatus: ConnectionStatus;
  streamEntries: StreamEntry[];
  activeNotifications: Set<string>;
  _btDevice: BtDevice | null;
  _gattServer: BtGattServer | null;
}

interface BluetoothActions {
  startScan: () => Promise<void>;
  connect: (device: BluetoothDeviceInfo) => Promise<void>;
  disconnect: () => void;
  readCharacteristic: (serviceUuid: string, charUuid: string) => Promise<void>;
  startNotify: (serviceUuid: string, charUuid: string) => Promise<void>;
  stopNotify: (charUuid: string) => Promise<void>;
  addStreamEntry: (entry: StreamEntry) => void;
  clearStream: () => void;
  setDevices: (devices: BluetoothDeviceInfo[]) => void;
  setServices: (services: GattService[]) => void;
}

export const useBluetoothStore = create<BluetoothState & BluetoothActions>(
  (set, get) => ({
    devices: [],
    activeDevice: null,
    services: [],
    isScanning: false,
    connectionStatus: "disconnected",
    streamEntries: [],
    activeNotifications: new Set<string>(),
    _btDevice: null,
    _gattServer: null,

    setDevices: (devices) => set({ devices }),
    setServices: (services) => set({ services }),
    clearStream: () => set({ streamEntries: [] }),

    addStreamEntry: (entry) =>
      set((s) => ({
        streamEntries: [entry, ...s.streamEntries].slice(0, 500),
      })),

    startScan: async () => {
      const nav = navigator as unknown as BtNavigator;
      if (!nav.bluetooth) {
        throw new Error("Web Bluetooth API not supported in this browser.");
      }
      set({ isScanning: true, connectionStatus: "connecting" });
      try {
        const btDevice = await nav.bluetooth.requestDevice({
          acceptAllDevices: true,
          optionalServices: [
            "device_information",
            "heart_rate",
            "battery_service",
            "generic_access",
            "generic_attribute",
            "health_thermometer",
            "blood_pressure",
            "cycling_speed_and_cadence",
            "running_speed_and_cadence",
            "00001810-0000-1000-8000-00805f9b34fb",
            "00001816-0000-1000-8000-00805f9b34fb",
            "00001818-0000-1000-8000-00805f9b34fb",
            "00001819-0000-1000-8000-00805f9b34fb",
          ],
        });

        const deviceInfo: BluetoothDeviceInfo = {
          id: btDevice.id,
          name: btDevice.name ?? "Unknown Device",
          rssi: null,
          serviceUuids: [],
          connected: false,
        };

        set((s) => ({
          devices: [
            ...s.devices.filter((d) => d.id !== deviceInfo.id),
            deviceInfo,
          ],
          _btDevice: btDevice,
        }));

        await get().connect(deviceInfo);
      } catch (err) {
        set({ connectionStatus: "disconnected" });
        throw err;
      } finally {
        set({ isScanning: false });
      }
    },

    connect: async (deviceInfo) => {
      const { _btDevice } = get();
      if (!_btDevice) return;
      set({ connectionStatus: "connecting" });

      try {
        const server = await _btDevice.gatt!.connect();
        set({ _gattServer: server });

        const btServices = await server.getPrimaryServices();
        const services: GattService[] = await Promise.all(
          btServices.map(async (svc) => {
            const chars = await svc.getCharacteristics();
            const characteristics = await Promise.all(
              chars.map(async (ch) => {
                let rawValue: Uint8Array | null = null;
                try {
                  if (ch.properties.read) {
                    const val = await ch.readValue();
                    rawValue = new Uint8Array(val.buffer);
                  }
                } catch {
                  // Some characteristics throw on read — silently skip
                }
                return {
                  uuid: ch.uuid,
                  properties: Object.entries(ch.properties)
                    .filter(([, v]) => v === true)
                    .map(([k]) => k),
                  rawValue,
                };
              }),
            );
            return { uuid: svc.uuid, characteristics };
          }),
        );

        const updated: BluetoothDeviceInfo = {
          ...deviceInfo,
          serviceUuids: btServices.map((s) => s.uuid),
          connected: true,
        };

        set((s) => ({
          activeDevice: updated,
          services,
          connectionStatus: "connected",
          devices: s.devices.map((d) => (d.id === updated.id ? updated : d)),
        }));

        _btDevice.addEventListener("gattserverdisconnected", () => {
          set((s) => ({
            activeDevice: s.activeDevice
              ? { ...s.activeDevice, connected: false }
              : null,
            connectionStatus: "disconnected",
            _gattServer: null,
            activeNotifications: new Set<string>(),
          }));
        });
      } catch (err) {
        set({ connectionStatus: "disconnected" });
        console.error("BT connect error:", err);
        throw err;
      }
    },

    disconnect: () => {
      // Stop all active notifications first
      for (const [uuid, handler] of _notifyHandlers.entries()) {
        const ch = _notifyChars.get(uuid);
        if (ch) {
          try {
            ch.stopNotifications();
          } catch {
            /* ignore */
          }
          ch.removeEventListener("characteristicvaluechanged", handler);
        }
      }
      _notifyHandlers.clear();
      _notifyChars.clear();

      const { _btDevice, _gattServer } = get();
      if (_gattServer?.connected) _gattServer.disconnect();
      if (_btDevice) _btDevice.gatt?.disconnect();
      set((s) => ({
        activeDevice: s.activeDevice
          ? { ...s.activeDevice, connected: false }
          : null,
        connectionStatus: "disconnected",
        services: [],
        _gattServer: null,
        activeNotifications: new Set<string>(),
      }));
    },

    readCharacteristic: async (serviceUuid, charUuid) => {
      const { _gattServer } = get();
      if (!_gattServer) return;
      try {
        const svc = await _gattServer.getPrimaryService(serviceUuid);
        const ch = await svc.getCharacteristic(charUuid);
        const val = await ch.readValue();
        const rawValue = new Uint8Array(val.buffer);
        set((s) => ({
          services: s.services.map((sv) =>
            sv.uuid === serviceUuid
              ? {
                  ...sv,
                  characteristics: sv.characteristics.map((c) =>
                    c.uuid === charUuid ? { ...c, rawValue } : c,
                  ),
                }
              : sv,
          ),
        }));
      } catch (err) {
        console.error("Read char error:", err);
        throw err;
      }
    },

    startNotify: async (serviceUuid, charUuid) => {
      const { _gattServer } = get();
      if (!_gattServer) return;
      if (_notifyHandlers.has(charUuid)) return; // already subscribed
      try {
        const svc = await _gattServer.getPrimaryService(serviceUuid);
        const ch = await svc.getCharacteristic(charUuid);
        const notifiedChar = await ch.startNotifications();
        const handler = (e: { target: { value: DataView } }) => {
          const rawValue = new Uint8Array(e.target.value.buffer);
          get().addStreamEntry({
            timestamp: Date.now(),
            serviceUuid,
            characteristicUuid: charUuid,
            rawValue,
          });
        };
        notifiedChar.addEventListener("characteristicvaluechanged", handler);
        _notifyHandlers.set(charUuid, handler);
        _notifyChars.set(charUuid, notifiedChar);
        set((s) => ({
          activeNotifications: new Set([...s.activeNotifications, charUuid]),
        }));
      } catch (err) {
        console.error("Start notify error:", err);
        throw err;
      }
    },

    stopNotify: async (charUuid) => {
      const handler = _notifyHandlers.get(charUuid);
      const ch = _notifyChars.get(charUuid);
      if (ch && handler) {
        try {
          await ch.stopNotifications();
          ch.removeEventListener("characteristicvaluechanged", handler);
        } catch {
          /* ignore */
        }
        _notifyHandlers.delete(charUuid);
        _notifyChars.delete(charUuid);
      }
      set((s) => {
        const next = new Set(s.activeNotifications);
        next.delete(charUuid);
        return { activeNotifications: next };
      });
    },
  }),
);
