import { create } from "zustand";
interface AudioState {
  entries: never[];
}
export const useAudioStore = create<AudioState>(() => ({ entries: [] }));
