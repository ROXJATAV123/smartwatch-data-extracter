import { create } from "zustand";
interface ImageState {
  entries: never[];
}
export const useImageStore = create<ImageState>(() => ({ entries: [] }));
