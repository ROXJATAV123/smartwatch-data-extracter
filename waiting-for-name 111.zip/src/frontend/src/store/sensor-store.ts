import { create } from "zustand";

export interface MotionData {
  timestamp: number;
  acceleration: { x: number | null; y: number | null; z: number | null };
  accelerationIncludingGravity: {
    x: number | null;
    y: number | null;
    z: number | null;
  };
  rotationRate: {
    alpha: number | null;
    beta: number | null;
    gamma: number | null;
  };
  interval: number | null;
}

export interface OrientationData {
  timestamp: number;
  alpha: number | null;
  beta: number | null;
  gamma: number | null;
  absolute: boolean;
}

export interface BatteryData {
  charging: boolean;
  chargingTime: number;
  dischargingTime: number;
  level: number;
  timestamp: number;
}

export interface NetworkData {
  type: string;
  effectiveType: string;
  downlink: number;
  rtt: number;
  saveData: boolean;
  timestamp: number;
}

export interface ScreenData {
  width: number;
  height: number;
  colorDepth: number;
  pixelDepth: number;
  orientationType: string;
  orientationAngle: number;
  devicePixelRatio: number;
}

export interface DeviceInfoData {
  userAgent: string;
  platform: string;
  language: string;
  hardwareConcurrency: number;
  deviceMemory: number | null;
  maxTouchPoints: number;
}

interface SensorState {
  motion: MotionData | null;
  orientation: OrientationData | null;
  battery: BatteryData | null;
  network: NetworkData | null;
  screen: ScreenData | null;
  deviceInfo: DeviceInfoData | null;
  motionSupported: boolean | null;
  orientationSupported: boolean | null;
  batterySupported: boolean | null;
  networkSupported: boolean | null;
  permissionRequested: boolean;
  isListening: boolean;
  setMotion: (data: MotionData) => void;
  setOrientation: (data: OrientationData) => void;
  setBattery: (data: BatteryData) => void;
  setNetwork: (data: NetworkData) => void;
  setScreen: (data: ScreenData) => void;
  setDeviceInfo: (data: DeviceInfoData) => void;
  setMotionSupported: (v: boolean) => void;
  setOrientationSupported: (v: boolean) => void;
  setBatterySupported: (v: boolean) => void;
  setNetworkSupported: (v: boolean) => void;
  setPermissionRequested: (v: boolean) => void;
  setIsListening: (v: boolean) => void;
}

export const useSensorStore = create<SensorState>((set) => ({
  motion: null,
  orientation: null,
  battery: null,
  network: null,
  screen: null,
  deviceInfo: null,
  motionSupported: null,
  orientationSupported: null,
  batterySupported: null,
  networkSupported: null,
  permissionRequested: false,
  isListening: false,
  setMotion: (data) => set({ motion: data }),
  setOrientation: (data) => set({ orientation: data }),
  setBattery: (data) => set({ battery: data }),
  setNetwork: (data) => set({ network: data }),
  setScreen: (data) => set({ screen: data }),
  setDeviceInfo: (data) => set({ deviceInfo: data }),
  setMotionSupported: (v) => set({ motionSupported: v }),
  setOrientationSupported: (v) => set({ orientationSupported: v }),
  setBatterySupported: (v) => set({ batterySupported: v }),
  setNetworkSupported: (v) => set({ networkSupported: v }),
  setPermissionRequested: (v) => set({ permissionRequested: v }),
  setIsListening: (v) => set({ isListening: v }),
}));
