import { create } from "zustand";
interface CallsState {
  entries: never[];
}
export const useCallsStore = create<CallsState>(() => ({ entries: [] }));
