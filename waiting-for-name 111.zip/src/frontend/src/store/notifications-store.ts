import { create } from "zustand";
interface NotificationsState {
  entries: never[];
}
export const useNotificationsStore = create<NotificationsState>(() => ({
  entries: [],
}));
