import type { LocationPoint } from "@/types";
import { create } from "zustand";

interface GpsState {
  currentLocation: LocationPoint | null;
  locationHistory: LocationPoint[];
  isTracking: boolean;
  intervalSec: number;
  error: string | null;
  _watchId: number | null;
  _intervalId: ReturnType<typeof setInterval> | null;
}

interface GpsActions {
  startTracking: () => void;
  stopTracking: () => void;
  setIntervalSec: (sec: number) => void;
  clearHistory: () => void;
}

function geoPositionToPoint(pos: GeolocationPosition): LocationPoint {
  return {
    lat: pos.coords.latitude,
    lng: pos.coords.longitude,
    accuracy: pos.coords.accuracy,
    altitude: pos.coords.altitude,
    speed: pos.coords.speed,
    heading: pos.coords.heading,
    timestamp: pos.timestamp,
  };
}

export const useGpsStore = create<GpsState & GpsActions>((set, get) => ({
  currentLocation: null,
  locationHistory: [],
  isTracking: false,
  intervalSec: 5,
  error: null,
  _watchId: null,
  _intervalId: null,

  setIntervalSec: (sec) => {
    set({ intervalSec: sec });
    const { isTracking } = get();
    if (isTracking) {
      get().stopTracking();
      get().startTracking();
    }
  },

  clearHistory: () => set({ locationHistory: [] }),

  startTracking: () => {
    if (!navigator.geolocation) {
      set({ error: "Geolocation API not supported." });
      return;
    }

    const onSuccess = (pos: GeolocationPosition) => {
      const point = geoPositionToPoint(pos);
      set((s) => ({
        currentLocation: point,
        error: null,
        locationHistory: [point, ...s.locationHistory].slice(0, 1000),
      }));
    };

    const onError = (err: GeolocationPositionError) => {
      set({ error: err.message, isTracking: false });
    };

    const { intervalSec } = get();

    // Use watchPosition for live updates
    const watchId = navigator.geolocation.watchPosition(onSuccess, onError, {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 0,
    });

    // Also poll on the configured interval for history sampling
    const intervalId = setInterval(() => {
      navigator.geolocation.getCurrentPosition(onSuccess, onError, {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: intervalSec * 1000,
      });
    }, intervalSec * 1000);

    set({
      isTracking: true,
      error: null,
      _watchId: watchId,
      _intervalId: intervalId,
    });
  },

  stopTracking: () => {
    const { _watchId, _intervalId } = get();
    if (_watchId !== null) navigator.geolocation.clearWatch(_watchId);
    if (_intervalId !== null) clearInterval(_intervalId);
    set({ isTracking: false, _watchId: null, _intervalId: null });
  },
}));
