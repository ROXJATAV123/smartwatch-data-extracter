import { Layout } from "@/components/Layout";
import { useBluetoothStore } from "@/store/bluetooth-store";
import { useGpsStore } from "@/store/gps-store";
import { Suspense, lazy, useState } from "react";

export type Tab =
  | "bluetooth"
  | "gps"
  | "file-upload"
  | "sensors"
  | "fitness"
  | "data-availability";

// Lazy-loaded page components
const BluetoothPage = lazy(() => import("@/pages/BluetoothPage"));
const GpsPage = lazy(() => import("@/pages/GpsPage"));
const DataAvailabilityPage = lazy(() => import("@/pages/DataAvailabilityPage"));
const FileUploadPage = lazy(() => import("@/pages/FileUploadPage"));
const SensorPage = lazy(() => import("@/pages/SensorPage"));
const FitnessPage = lazy(() => import("@/pages/FitnessPage"));

const LoadingFallback = (
  <div className="flex items-center justify-center h-40">
    <span className="font-mono text-xs text-muted-foreground animate-pulse">
      Loading...
    </span>
  </div>
);

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("bluetooth");
  const btConnected = useBluetoothStore(
    (s) => s.activeDevice?.connected ?? false,
  );
  const gpsTracking = useGpsStore((s) => s.isTracking);

  function renderPage() {
    switch (activeTab) {
      case "bluetooth":
        return <BluetoothPage />;
      case "gps":
        return <GpsPage />;
      case "file-upload":
        return <FileUploadPage />;
      case "sensors":
        return <SensorPage />;
      case "fitness":
        return <FitnessPage />;
      case "data-availability":
        return <DataAvailabilityPage />;
    }
  }

  return (
    <Layout
      activeTab={activeTab}
      onTabChange={(tab) => setActiveTab(tab as Tab)}
      btConnected={btConnected}
      gpsTracking={gpsTracking}
    >
      <Suspense fallback={LoadingFallback}>{renderPage()}</Suspense>
    </Layout>
  );
}
