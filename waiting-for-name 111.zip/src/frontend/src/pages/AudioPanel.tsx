export default function AudioPanel() {
  return null;
}
