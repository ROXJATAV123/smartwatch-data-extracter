export default function VideoPanel() {
  return null;
}
