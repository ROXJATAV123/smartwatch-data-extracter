export default function CallLogsPanel() {
  return null;
}
