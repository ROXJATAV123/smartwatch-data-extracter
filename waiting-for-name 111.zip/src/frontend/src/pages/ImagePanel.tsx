export default function ImagePanel() {
  return null;
}
