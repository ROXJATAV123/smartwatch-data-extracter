export default function MessageLogsPanel() {
  return null;
}
