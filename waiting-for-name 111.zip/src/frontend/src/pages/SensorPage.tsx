import { useSensorStore } from "@/store/sensor-store";
import type {
  BatteryData,
  DeviceInfoData,
  MotionData,
  NetworkData,
  OrientationData,
  ScreenData,
} from "@/store/sensor-store";
import { Activity, Cpu, Globe, Monitor, Navigation, Zap } from "lucide-react";
import { useEffect } from "react";

// Declare extended navigator types
declare global {
  interface Navigator {
    deviceMemory?: number;
    connection?: {
      type?: string;
      effectiveType?: string;
      downlink?: number;
      rtt?: number;
      saveData?: boolean;
      addEventListener?: (type: string, listener: () => void) => void;
      removeEventListener?: (type: string, listener: () => void) => void;
    };
  }
  interface Window {
    DeviceMotionEvent?: {
      requestPermission?: () => Promise<string>;
    };
  }
}

// Float32 → hex (4 bytes IEEE 754)
function float32Hex(val: number): string {
  const buf = new ArrayBuffer(4);
  new DataView(buf).setFloat32(0, val, false);
  const bytes = new Uint8Array(buf);
  return Array.from(bytes)
    .map((b) => b.toString(16).toUpperCase().padStart(2, "0"))
    .join(" ");
}

function float32Binary(val: number): string {
  const buf = new ArrayBuffer(4);
  new DataView(buf).setFloat32(0, val, false);
  const bytes = new Uint8Array(buf);
  return Array.from(bytes)
    .map((b) => b.toString(2).padStart(8, "0"))
    .join(" ");
}

function formatTs(ts: number): string {
  const d = new Date(ts);
  return `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}:${d.getSeconds().toString().padStart(2, "0")}.${d.getMilliseconds().toString().padStart(3, "0")}`;
}

function SensorRow({
  label,
  value,
  unit = "",
  showBits = false,
  available = true,
}: {
  label: string;
  value: string | number | null;
  unit?: string;
  showBits?: boolean;
  available?: boolean;
}) {
  const displayValue = !available
    ? "Not Available"
    : value === null
      ? "null"
      : `${value}${unit ? ` ${unit}` : ""}`;
  const numVal = typeof value === "number" ? value : null;

  return (
    <div className="border-b border-border/20 px-3 py-1.5 hover:bg-muted/10 transition-colors">
      <div className="flex items-start justify-between gap-2 min-w-0">
        <span className="font-mono text-xs text-muted-foreground w-44 shrink-0">
          {label}
        </span>
        <span
          className={[
            "font-mono text-xs",
            !available ? "text-destructive/60" : "text-foreground",
          ].join(" ")}
        >
          {displayValue}
        </span>
      </div>
      {showBits && numVal !== null && available && (
        <div className="ml-44 mt-0.5 space-y-0.5">
          <div className="font-mono text-[9px] text-accent/70">
            HEX: {float32Hex(numVal)}
          </div>
          <div
            className="font-mono text-[9px] break-all"
            style={{ color: "oklch(var(--accent-image) / 0.7)" }}
          >
            BIN: {float32Binary(numVal)}
          </div>
        </div>
      )}
    </div>
  );
}

function SectionBlock({
  icon,
  title,
  titleHi,
  accentColor,
  timestamp,
  children,
  ocid,
}: {
  icon: React.ReactNode;
  title: string;
  titleHi: string;
  accentColor: string;
  timestamp?: number | null;
  children: React.ReactNode;
  ocid: string;
}) {
  return (
    <section
      className="border border-border rounded-sm overflow-hidden"
      data-ocid={ocid}
    >
      <div
        className="flex items-center justify-between px-3 py-2 bg-muted/30 border-b border-border border-l-2"
        style={{ borderLeftColor: accentColor }}
      >
        <div className="flex items-center gap-2">
          <span style={{ color: accentColor }}>{icon}</span>
          <span className="font-mono text-xs font-semibold text-foreground uppercase tracking-widest">
            {title}
          </span>
          <span className="font-mono text-xs text-muted-foreground">
            · {titleHi}
          </span>
        </div>
        {timestamp != null && (
          <span className="font-mono text-[10px] text-muted-foreground/60">
            {formatTs(timestamp)}
          </span>
        )}
      </div>
      <div>{children}</div>
    </section>
  );
}

export default function SensorPage() {
  const {
    motion,
    orientation,
    battery,
    network,
    screen,
    deviceInfo,
    motionSupported,
    orientationSupported,
    batterySupported,
    networkSupported,
    permissionRequested,
    isListening,
  } = useSensorStore();

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    const store = useSensorStore.getState();
    // Screen
    const sc: ScreenData = {
      width: window.screen.width,
      height: window.screen.height,
      colorDepth: window.screen.colorDepth,
      pixelDepth: window.screen.pixelDepth,
      orientationType: window.screen.orientation?.type ?? "unknown",
      orientationAngle: window.screen.orientation?.angle ?? 0,
      devicePixelRatio: window.devicePixelRatio,
    };
    store.setScreen(sc);

    // Device info
    const di: DeviceInfoData = {
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      language: navigator.language,
      hardwareConcurrency: navigator.hardwareConcurrency,
      deviceMemory: navigator.deviceMemory ?? null,
      maxTouchPoints: navigator.maxTouchPoints,
    };
    store.setDeviceInfo(di);

    // Network
    const conn = navigator.connection;
    if (conn) {
      store.setNetworkSupported(true);
      const readNet = () => {
        const nd: NetworkData = {
          type: conn.type ?? "unknown",
          effectiveType: conn.effectiveType ?? "unknown",
          downlink: conn.downlink ?? 0,
          rtt: conn.rtt ?? 0,
          saveData: conn.saveData ?? false,
          timestamp: Date.now(),
        };
        useSensorStore.getState().setNetwork(nd);
      };
      readNet();
      conn.addEventListener?.("change", readNet);
    } else {
      store.setNetworkSupported(false);
    }

    // Battery
    if ("getBattery" in navigator) {
      store.setBatterySupported(true);
      (navigator as Navigator & { getBattery: () => Promise<BatteryManager> })
        .getBattery()
        .then((b: BatteryManager) => {
          const readBat = () => {
            const bd: BatteryData = {
              charging: b.charging,
              chargingTime: b.chargingTime,
              dischargingTime: b.dischargingTime,
              level: b.level,
              timestamp: Date.now(),
            };
            useSensorStore.getState().setBattery(bd);
          };
          readBat();
          b.addEventListener("chargingchange", readBat);
          b.addEventListener("levelchange", readBat);
          b.addEventListener("chargingtimechange", readBat);
          b.addEventListener("dischargingtimechange", readBat);
        })
        .catch(() => useSensorStore.getState().setBatterySupported(false));
    } else {
      store.setBatterySupported(false);
    }
  }, []); // run once on mount — store getState() is always current

  function startMotionListeners() {
    useSensorStore.getState().setPermissionRequested(true);
    useSensorStore.getState().setIsListening(true);

    const handleMotion = (e: DeviceMotionEvent) => {
      const md: MotionData = {
        timestamp: Date.now(),
        acceleration: {
          x: e.acceleration?.x ?? null,
          y: e.acceleration?.y ?? null,
          z: e.acceleration?.z ?? null,
        },
        accelerationIncludingGravity: {
          x: e.accelerationIncludingGravity?.x ?? null,
          y: e.accelerationIncludingGravity?.y ?? null,
          z: e.accelerationIncludingGravity?.z ?? null,
        },
        rotationRate: {
          alpha: e.rotationRate?.alpha ?? null,
          beta: e.rotationRate?.beta ?? null,
          gamma: e.rotationRate?.gamma ?? null,
        },
        interval: e.interval,
      };
      useSensorStore.getState().setMotion(md);
      useSensorStore.getState().setMotionSupported(true);
    };

    const handleOrientation = (e: DeviceOrientationEvent) => {
      const od: OrientationData = {
        timestamp: Date.now(),
        alpha: e.alpha,
        beta: e.beta,
        gamma: e.gamma,
        absolute: e.absolute,
      };
      useSensorStore.getState().setOrientation(od);
      useSensorStore.getState().setOrientationSupported(true);
    };

    window.addEventListener("devicemotion", handleMotion);
    window.addEventListener("deviceorientation", handleOrientation);

    // Check support after short delay
    setTimeout(() => {
      if (!useSensorStore.getState().motion)
        useSensorStore.getState().setMotionSupported(false);
      if (!useSensorStore.getState().orientation)
        useSensorStore.getState().setOrientationSupported(false);
    }, 1500);
  }

  async function requestMotionPermission() {
    const DevMotion = window.DeviceMotionEvent as typeof DeviceMotionEvent & {
      requestPermission?: () => Promise<"granted" | "denied">;
    };
    if (typeof DevMotion?.requestPermission === "function") {
      const result = await DevMotion.requestPermission();
      if (result === "granted") startMotionListeners();
      else {
        useSensorStore.getState().setMotionSupported(false);
        useSensorStore.getState().setOrientationSupported(false);
        useSensorStore.getState().setPermissionRequested(true);
      }
    } else {
      startMotionListeners();
    }
  }

  const motionOk = motionSupported !== false;
  const orientOk = orientationSupported !== false;

  return (
    <div
      className="min-h-0 overflow-auto"
      style={{ height: "calc(100vh - 88px)" }}
      data-ocid="sensors.page"
    >
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-5">
        {/* Header */}
        <div className="flex items-center gap-2">
          <Activity
            className="w-4 h-4"
            style={{ color: "oklch(var(--accent-call))" }}
          />
          <h1 className="font-mono text-sm font-semibold text-foreground uppercase tracking-widest">
            Phone Sensor Data
          </h1>
          <span className="font-mono text-xs text-muted-foreground">
            · फोन सेंसर डेटा
          </span>
        </div>

        {/* Permission prompt */}
        {!permissionRequested && (
          <div
            className="border rounded-sm p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
            style={
              {
                borderColor: "oklch(var(--accent-call) / 0.4)",
                backgroundColor: "oklch(var(--accent-call) / 0.05)",
              } as React.CSSProperties
            }
            data-ocid="sensors.permission_banner"
          >
            <div className="space-y-1">
              <p className="font-mono text-xs text-foreground font-semibold">
                Motion & Orientation sensors require user activation
              </p>
              <p className="font-mono text-xs text-muted-foreground">
                Motion और Orientation sensors के लिए permission ज़रूरी है (iOS)
              </p>
            </div>
            <button
              type="button"
              data-ocid="sensors.request_permission_button"
              onClick={requestMotionPermission}
              className="font-mono text-xs px-4 py-1.5 rounded-sm transition-colors shrink-0 border"
              style={
                {
                  borderColor: "oklch(var(--accent-call) / 0.6)",
                  color: "oklch(var(--accent-call))",
                } as React.CSSProperties
              }
            >
              Enable Motion Sensors
            </button>
          </div>
        )}

        {/* Motion / Accelerometer */}
        <SectionBlock
          icon={<Activity className="w-3.5 h-3.5" />}
          title="Motion / Accelerometer"
          titleHi="एक्सेलेरोमीटर"
          accentColor="oklch(var(--accent-call))"
          timestamp={motion?.timestamp}
          ocid="sensors.motion_section"
        >
          {!isListening ? (
            <div className="px-3 py-3 font-mono text-xs text-muted-foreground">
              Click "Enable Motion Sensors" above to start · ऊपर button दबाएं
            </div>
          ) : (
            <>
              <SensorRow
                label="accel.x (m/s²)"
                value={motion?.acceleration.x ?? null}
                showBits
                available={motionOk}
              />
              <SensorRow
                label="accel.y (m/s²)"
                value={motion?.acceleration.y ?? null}
                showBits
                available={motionOk}
              />
              <SensorRow
                label="accel.z (m/s²)"
                value={motion?.acceleration.z ?? null}
                showBits
                available={motionOk}
              />
              <SensorRow
                label="accelG.x (m/s²)"
                value={motion?.accelerationIncludingGravity.x ?? null}
                showBits
                available={motionOk}
              />
              <SensorRow
                label="accelG.y (m/s²)"
                value={motion?.accelerationIncludingGravity.y ?? null}
                showBits
                available={motionOk}
              />
              <SensorRow
                label="accelG.z (m/s²)"
                value={motion?.accelerationIncludingGravity.z ?? null}
                showBits
                available={motionOk}
              />
              <SensorRow
                label="interval (ms)"
                value={motion?.interval ?? null}
                available={motionOk}
              />
            </>
          )}
        </SectionBlock>

        {/* Gyroscope / Orientation */}
        <SectionBlock
          icon={<Navigation className="w-3.5 h-3.5" />}
          title="Gyroscope / Orientation"
          titleHi="जायरोस्कोप"
          accentColor="oklch(var(--primary))"
          timestamp={orientation?.timestamp}
          ocid="sensors.orientation_section"
        >
          {!isListening ? (
            <div className="px-3 py-3 font-mono text-xs text-muted-foreground">
              Enable sensors first · पहले sensors enable करें
            </div>
          ) : (
            <>
              <SensorRow
                label="rotation.alpha (°)"
                value={motion?.rotationRate.alpha ?? null}
                showBits
                available={orientOk}
              />
              <SensorRow
                label="rotation.beta (°)"
                value={motion?.rotationRate.beta ?? null}
                showBits
                available={orientOk}
              />
              <SensorRow
                label="rotation.gamma (°)"
                value={motion?.rotationRate.gamma ?? null}
                showBits
                available={orientOk}
              />
              <SensorRow
                label="orient.alpha (°)"
                value={orientation?.alpha ?? null}
                showBits
                available={orientOk}
              />
              <SensorRow
                label="orient.beta (°)"
                value={orientation?.beta ?? null}
                showBits
                available={orientOk}
              />
              <SensorRow
                label="orient.gamma (°)"
                value={orientation?.gamma ?? null}
                showBits
                available={orientOk}
              />
              <SensorRow
                label="absolute"
                value={orientation?.absolute ? "true" : "false"}
                available={orientOk}
              />
            </>
          )}
        </SectionBlock>

        {/* Battery */}
        <SectionBlock
          icon={<Zap className="w-3.5 h-3.5" />}
          title="Battery Status"
          titleHi="बैटरी स्टेटस"
          accentColor="oklch(var(--accent))"
          timestamp={battery?.timestamp}
          ocid="sensors.battery_section"
        >
          {batterySupported === false ? (
            <div className="px-3 py-3 font-mono text-xs text-destructive/70">
              Battery Status API not available in this browser · इस browser में
              उपलब्ध नहीं
            </div>
          ) : battery ? (
            <>
              <SensorRow
                label="level"
                value={`${(battery.level * 100).toFixed(1)}%`}
              />
              <SensorRow
                label="charging"
                value={
                  battery.charging ? "true (charging)" : "false (not charging)"
                }
              />
              <SensorRow
                label="chargingTime (s)"
                value={
                  battery.chargingTime === Number.POSITIVE_INFINITY
                    ? "Infinity"
                    : battery.chargingTime.toString()
                }
              />
              <SensorRow
                label="dischargingTime (s)"
                value={
                  battery.dischargingTime === Number.POSITIVE_INFINITY
                    ? "Infinity"
                    : battery.dischargingTime.toString()
                }
              />
            </>
          ) : (
            <div className="px-3 py-3 font-mono text-xs text-muted-foreground animate-pulse">
              Reading battery...
            </div>
          )}
        </SectionBlock>

        {/* Network */}
        <SectionBlock
          icon={<Globe className="w-3.5 h-3.5" />}
          title="Network Information"
          titleHi="नेटवर्क जानकारी"
          accentColor="oklch(var(--accent-message))"
          timestamp={network?.timestamp}
          ocid="sensors.network_section"
        >
          {networkSupported === false ? (
            <div className="px-3 py-3 font-mono text-xs text-destructive/70">
              NetworkInformation API not available · इस browser में उपलब्ध नहीं
            </div>
          ) : network ? (
            <>
              <SensorRow label="type" value={network.type} />
              <SensorRow label="effectiveType" value={network.effectiveType} />
              <SensorRow label="downlink (Mbps)" value={network.downlink} />
              <SensorRow label="rtt (ms)" value={network.rtt} />
              <SensorRow
                label="saveData"
                value={network.saveData ? "true" : "false"}
              />
            </>
          ) : (
            <div className="px-3 py-3 font-mono text-xs text-muted-foreground animate-pulse">
              Reading network...
            </div>
          )}
        </SectionBlock>

        {/* Screen / Display */}
        <SectionBlock
          icon={<Monitor className="w-3.5 h-3.5" />}
          title="Screen / Display"
          titleHi="स्क्रीन जानकारी"
          accentColor="oklch(var(--accent-image))"
          ocid="sensors.screen_section"
        >
          {screen ? (
            <>
              <SensorRow label="width (px)" value={screen.width} />
              <SensorRow label="height (px)" value={screen.height} />
              <SensorRow label="colorDepth (bits)" value={screen.colorDepth} />
              <SensorRow label="pixelDepth (bits)" value={screen.pixelDepth} />
              <SensorRow
                label="devicePixelRatio"
                value={screen.devicePixelRatio}
                showBits
              />
              <SensorRow
                label="orientation.type"
                value={screen.orientationType}
              />
              <SensorRow
                label="orientation.angle (°)"
                value={screen.orientationAngle}
              />
            </>
          ) : (
            <div className="px-3 py-3 font-mono text-xs text-muted-foreground">
              Loading...
            </div>
          )}
        </SectionBlock>

        {/* Device Info */}
        <SectionBlock
          icon={<Cpu className="w-3.5 h-3.5" />}
          title="Device Info"
          titleHi="डिवाइस जानकारी"
          accentColor="oklch(var(--accent-notification))"
          ocid="sensors.device_info_section"
        >
          {deviceInfo ? (
            <>
              <SensorRow label="userAgent" value={deviceInfo.userAgent} />
              <SensorRow label="platform" value={deviceInfo.platform} />
              <SensorRow label="language" value={deviceInfo.language} />
              <SensorRow
                label="hardwareConcurrency"
                value={deviceInfo.hardwareConcurrency}
              />
              <SensorRow
                label="deviceMemory (GB)"
                value={deviceInfo.deviceMemory ?? "N/A"}
                available={deviceInfo.deviceMemory !== null}
              />
              <SensorRow
                label="maxTouchPoints"
                value={deviceInfo.maxTouchPoints}
              />
            </>
          ) : (
            <div className="px-3 py-3 font-mono text-xs text-muted-foreground">
              Loading...
            </div>
          )}
        </SectionBlock>
      </div>
    </div>
  );
}

// Type for Battery Manager API
interface BatteryManager extends EventTarget {
  charging: boolean;
  chargingTime: number;
  dischargingTime: number;
  level: number;
}
