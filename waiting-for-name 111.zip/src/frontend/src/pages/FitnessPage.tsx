import { useBluetoothStore } from "@/store/bluetooth-store";
import type { FitnessCharSnapshot } from "@/store/fitness-store";
import { useFitnessStore } from "@/store/fitness-store";
import { bytesToHexDump, formatTimestampMs } from "@/utils/data-format";
import type {
  BatteryData,
  CscData,
  HeartRateData,
  RscData,
} from "@/utils/gatt-decoders";
import {
  Activity,
  AlertCircle,
  Bike,
  Bluetooth,
  CheckCircle,
  ChevronDown,
  ChevronRight,
  Cpu,
  Heart,
  Loader2,
  RefreshCw,
  Watch,
  Zap,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";

// ─── Types ─────────────────────────────────────────────────────────────────────

type ViewMode = "parsed" | "hex" | "decimal" | "binary";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function isHeartRateData(v: unknown): v is HeartRateData {
  return typeof v === "object" && v !== null && "bpm" in v;
}
function isRscData(v: unknown): v is RscData {
  return (
    typeof v === "object" &&
    v !== null &&
    "cadence" in v &&
    "speed" in v &&
    "isRunning" in v
  );
}
function isCscData(v: unknown): v is CscData {
  return typeof v === "object" && v !== null && "crankRevolutions" in v;
}
function isBatteryData(v: unknown): v is BatteryData {
  return typeof v === "object" && v !== null && "percent" in v;
}

// ─── HexDump viewer ────────────────────────────────────────────────────────────

interface RawDumpProps {
  bytes: number[];
  mode: ViewMode;
}

function RawDump({ bytes, mode }: RawDumpProps) {
  const rows = bytesToHexDump(new Uint8Array(bytes), 8);
  if (mode === "parsed") return null;
  return (
    <div className="font-mono text-[10px] overflow-auto max-h-36">
      <table className="w-full">
        <thead>
          <tr className="text-muted-foreground">
            <th className="text-left pr-3">Offset</th>
            {mode === "hex" && <th className="text-left">Hex Bytes</th>}
            {mode === "decimal" && <th className="text-left">Decimal</th>}
            {mode === "binary" && <th className="text-left">Binary</th>}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.offset} className="border-t border-border/30">
              <td className="pr-3 text-muted-foreground">
                +{row.offset.toString(16).padStart(4, "0")}
              </td>
              <td className="text-foreground space-x-1">
                {mode === "hex" &&
                  row.hex.map((h, i) => (
                    <span key={`${row.offset}-h-${i}`} className="text-primary">
                      {h}
                    </span>
                  ))}
                {mode === "decimal" &&
                  row.decimal.map((d, i) => (
                    <span key={`${row.offset}-d-${i}`} className="text-accent">
                      {d.toString().padStart(3, " ")}
                    </span>
                  ))}
                {mode === "binary" &&
                  row.bytes.map((b, i) => (
                    <span
                      key={`${row.offset}-b-${i}`}
                      className="text-[oklch(0.72_0.17_84)] text-[9px]"
                    >
                      {b.toString(2).padStart(8, "0")}
                    </span>
                  ))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Mode toggle bar ───────────────────────────────────────────────────────────

interface ModeSelectorProps {
  mode: ViewMode;
  onChange: (m: ViewMode) => void;
  ocidPrefix: string;
}

function ModeSelector({ mode, onChange, ocidPrefix }: ModeSelectorProps) {
  const modes: ViewMode[] = ["parsed", "hex", "decimal", "binary"];
  return (
    <div className="flex gap-0.5">
      {modes.map((m) => (
        <button
          key={m}
          type="button"
          data-ocid={`${ocidPrefix}.mode_${m}`}
          onClick={() => onChange(m)}
          className={[
            "font-mono text-[9px] px-1.5 py-0.5 rounded-sm uppercase transition-colors",
            mode === m
              ? "bg-primary/20 text-primary"
              : "text-muted-foreground hover:text-foreground",
          ].join(" ")}
        >
          {m === "parsed" ? "VAL" : m.slice(0, 3).toUpperCase()}
        </button>
      ))}
    </div>
  );
}

// ─── Metric card ───────────────────────────────────────────────────────────────

interface MetricCardProps {
  title: string;
  icon: React.ReactNode;
  snap: FitnessCharSnapshot;
  renderParsed: (snap: FitnessCharSnapshot) => React.ReactNode;
  ocidPrefix: string;
}

function MetricCard({
  title,
  icon,
  snap,
  renderParsed,
  ocidPrefix,
}: MetricCardProps) {
  const [mode, setMode] = useState<ViewMode>("parsed");
  const [expanded, setExpanded] = useState(false);
  const isNA =
    snap.error !== null && snap.parsed === null && snap.rawBytes === null;

  return (
    <div
      className="bg-card border border-border rounded-md overflow-hidden"
      data-ocid={`${ocidPrefix}.card`}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-border/50">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setExpanded(!expanded)}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            {expanded ? (
              <ChevronDown className="w-3 h-3" />
            ) : (
              <ChevronRight className="w-3 h-3" />
            )}
          </button>
          <span className="text-muted-foreground">{icon}</span>
          <span className="font-mono text-xs font-semibold text-foreground">
            {title}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {snap.updatedAt && (
            <span className="font-mono text-[9px] text-muted-foreground">
              {formatTimestampMs(snap.updatedAt)}
            </span>
          )}
          {!isNA && (
            <ModeSelector
              mode={mode}
              onChange={setMode}
              ocidPrefix={ocidPrefix}
            />
          )}
          {isNA ? (
            <AlertCircle className="w-3 h-3 text-muted-foreground/50" />
          ) : snap.parsed !== null ? (
            <CheckCircle className="w-3 h-3 text-primary" />
          ) : null}
        </div>
      </div>

      {/* Body */}
      <div className="px-3 py-2">
        {isNA ? (
          <div
            data-ocid={`${ocidPrefix}.not_available`}
            className="flex items-start gap-2"
          >
            <span className="font-mono text-[10px] text-muted-foreground/60 italic mt-0.5">
              NOT AVAILABLE
            </span>
            <span className="font-mono text-[10px] text-muted-foreground/50">
              — {snap.error}
            </span>
          </div>
        ) : mode === "parsed" ? (
          renderParsed(snap)
        ) : snap.rawBytes ? (
          <RawDump bytes={snap.rawBytes} mode={mode} />
        ) : (
          <span className="font-mono text-[10px] text-muted-foreground italic">
            No data yet
          </span>
        )}

        {/* Collapsible raw dump alongside parsed */}
        {expanded && mode === "parsed" && snap.rawBytes && (
          <div className="mt-2 pt-2 border-t border-border/30">
            <RawDump bytes={snap.rawBytes} mode="hex" />
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Section renderers ─────────────────────────────────────────────────────────

function HeartRateValue({ snap }: { snap: FitnessCharSnapshot }) {
  if (!snap.parsed)
    return (
      <span className="font-mono text-[10px] text-muted-foreground italic">
        Waiting for data...
      </span>
    );
  if (!isHeartRateData(snap.parsed)) return null;
  const d = snap.parsed;
  return (
    <div className="space-y-1">
      <div className="flex items-baseline gap-2">
        <span className="font-mono text-3xl font-bold text-primary">
          {d.bpm}
        </span>
        <span className="font-mono text-xs text-muted-foreground">BPM</span>
      </div>
      <div className="flex flex-wrap gap-3 mt-1">
        {d.sensorContact !== null && (
          <span
            className={`font-mono text-[10px] ${d.sensorContact ? "text-primary" : "text-destructive"}`}
          >
            Contact: {d.sensorContact ? "Detected" : "Not Detected"}
          </span>
        )}
        {d.energyExpended !== null && (
          <span className="font-mono text-[10px] text-muted-foreground">
            Energy: {d.energyExpended} kJ
          </span>
        )}
        {d.rrIntervals.length > 0 && (
          <span className="font-mono text-[10px] text-muted-foreground">
            RR: {d.rrIntervals.map((r) => `${r}ms`).join(", ")}
          </span>
        )}
      </div>
    </div>
  );
}

function RscValue({ snap }: { snap: FitnessCharSnapshot }) {
  if (!snap.parsed)
    return (
      <span className="font-mono text-[10px] text-muted-foreground italic">
        Waiting for data...
      </span>
    );
  if (!isRscData(snap.parsed)) return null;
  const d = snap.parsed;
  const speedKmh = (d.speed * 3.6).toFixed(2);
  return (
    <div className="grid grid-cols-2 gap-2">
      <StatBox
        label="Speed"
        value={`${d.speed.toFixed(3)} m/s`}
        sub={`${speedKmh} km/h`}
      />
      <StatBox label="Cadence" value={`${d.cadence}`} sub="steps/min" />
      {d.strideLength !== null && (
        <StatBox label="Stride" value={`${d.strideLength.toFixed(2)} m`} />
      )}
      {d.totalDistance !== null && (
        <StatBox label="Distance" value={`${d.totalDistance.toFixed(1)} m`} />
      )}
      <StatBox label="Mode" value={d.isRunning ? "Running 🏃" : "Walking 🚶"} />
    </div>
  );
}

function CscValue({ snap }: { snap: FitnessCharSnapshot }) {
  if (!snap.parsed)
    return (
      <span className="font-mono text-[10px] text-muted-foreground italic">
        Waiting for data...
      </span>
    );
  if (!isCscData(snap.parsed)) return null;
  const d = snap.parsed;
  return (
    <div className="grid grid-cols-2 gap-2">
      {d.wheelRevolutions !== null && (
        <StatBox label="Wheel Rev" value={`${d.wheelRevolutions}`} />
      )}
      {d.wheelEventTime !== null && (
        <StatBox
          label="Wheel Time"
          value={`${(d.wheelEventTime / 1024).toFixed(3)} s`}
        />
      )}
      {d.crankRevolutions !== null && (
        <StatBox label="Crank Rev" value={`${d.crankRevolutions}`} />
      )}
      {d.crankEventTime !== null && (
        <StatBox
          label="Crank Time"
          value={`${(d.crankEventTime / 1024).toFixed(3)} s`}
        />
      )}
    </div>
  );
}

function BatteryValue({ snap }: { snap: FitnessCharSnapshot }) {
  if (!snap.parsed)
    return (
      <span className="font-mono text-[10px] text-muted-foreground italic">
        Waiting for data...
      </span>
    );
  if (!isBatteryData(snap.parsed)) return null;
  const pct = snap.parsed.percent;
  const color =
    pct > 60 ? "bg-primary" : pct > 20 ? "bg-warning" : "bg-destructive";
  return (
    <div className="space-y-1">
      <div className="flex items-baseline gap-2">
        <span className="font-mono text-2xl font-bold text-foreground">
          {pct}%
        </span>
        <span className="font-mono text-xs text-muted-foreground">battery</span>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${color}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

function StringValue({ snap }: { snap: FitnessCharSnapshot }) {
  if (!snap.parsed)
    return (
      <span className="font-mono text-[10px] text-muted-foreground italic">
        Waiting for data...
      </span>
    );
  if (typeof snap.parsed !== "string") return null;
  return (
    <span className="font-mono text-xs text-foreground">{snap.parsed}</span>
  );
}

function StatBox({
  label,
  value,
  sub,
}: { label: string; value: string; sub?: string }) {
  return (
    <div className="bg-muted/30 rounded px-2 py-1.5">
      <div className="font-mono text-[9px] text-muted-foreground uppercase tracking-wider">
        {label}
      </div>
      <div className="font-mono text-sm font-semibold text-foreground mt-0.5">
        {value}
      </div>
      {sub && (
        <div className="font-mono text-[9px] text-muted-foreground">{sub}</div>
      )}
    </div>
  );
}

// ─── Not Available info cards ──────────────────────────────────────────────────

interface NACardProps {
  icon: React.ReactNode;
  title: string;
  reason: string;
  ocid: string;
}

function NACard({ icon, title, reason, ocid }: NACardProps) {
  return (
    <div
      className="bg-card border border-border/50 rounded-md px-3 py-2 flex items-start gap-3"
      data-ocid={ocid}
    >
      <span className="text-muted-foreground/40 mt-0.5">{icon}</span>
      <div className="min-w-0">
        <div className="font-mono text-xs font-semibold text-muted-foreground/60">
          {title}
        </div>
        <div className="font-mono text-[10px] text-muted-foreground/40 mt-0.5 italic">
          NOT AVAILABLE — {reason}
        </div>
      </div>
    </div>
  );
}

// ─── Connect prompt ────────────────────────────────────────────────────────────

function ConnectPrompt({ onScanClick }: { onScanClick: () => void }) {
  return (
    <div
      className="flex flex-col items-center justify-center h-64 gap-4"
      data-ocid="fitness.connect_prompt"
    >
      <Watch className="w-12 h-12 text-muted-foreground/30" />
      <div className="text-center">
        <p className="font-mono text-sm text-muted-foreground">
          No smartwatch connected
        </p>
        <p className="font-mono text-[10px] text-muted-foreground/60 mt-1">
          Connect your smartwatch via Bluetooth to extract real fitness data
        </p>
      </div>
      <button
        type="button"
        data-ocid="fitness.connect_button"
        onClick={onScanClick}
        className="flex items-center gap-2 font-mono text-xs px-4 py-2 rounded border border-primary/40 text-primary hover:bg-primary/10 transition-colors"
      >
        <Bluetooth className="w-3.5 h-3.5" />
        Connect Smartwatch
      </button>
    </div>
  );
}

// ─── Main Page ──────────────────────────────────────────────────────────────────

export default function FitnessPage() {
  const { activeDevice, _gattServer, startScan } = useBluetoothStore();
  const { snapshot, isLoadingMetrics, loadError, loadMetrics, reset } =
    useFitnessStore();
  const loadedRef = useRef(false);

  const isConnected = activeDevice?.connected === true;

  // Auto-load metrics once on connect
  useEffect(() => {
    if (isConnected && _gattServer && !loadedRef.current) {
      loadedRef.current = true;
      loadMetrics(_gattServer as unknown as Parameters<typeof loadMetrics>[0]);
    }
    if (!isConnected) {
      loadedRef.current = false;
    }
  }, [isConnected, _gattServer, loadMetrics]);

  function handleRefresh() {
    if (_gattServer) {
      reset();
      loadedRef.current = false;
      loadMetrics(_gattServer as unknown as Parameters<typeof loadMetrics>[0]);
    }
  }

  if (!isConnected) {
    return (
      <div className="p-4">
        <ConnectPrompt onScanClick={() => startScan().catch(() => {})} />
        <VendorUnavailableSection />
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4" data-ocid="fitness.page">
      {/* Toolbar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-primary" />
          <span className="font-mono text-xs font-semibold text-foreground">
            Fitness Metrics — {activeDevice?.name ?? "Device"}
          </span>
          {isLoadingMetrics && (
            <Loader2 className="w-3 h-3 text-muted-foreground animate-spin" />
          )}
        </div>
        <button
          type="button"
          data-ocid="fitness.refresh_button"
          onClick={handleRefresh}
          disabled={isLoadingMetrics}
          className="flex items-center gap-1 font-mono text-[10px] px-2 py-1 rounded border border-border/60 text-muted-foreground hover:text-foreground hover:border-border transition-colors disabled:opacity-40"
        >
          <RefreshCw className="w-3 h-3" />
          Refresh
        </button>
      </div>

      {loadError && (
        <div className="bg-destructive/10 border border-destructive/30 rounded px-3 py-2 font-mono text-[10px] text-destructive">
          {loadError}
        </div>
      )}

      {/* GATT Fitness Metrics */}
      <section data-ocid="fitness.metrics_section">
        <SectionHeading
          icon={<Heart className="w-3 h-3" />}
          label="Heart Rate (0x180D)"
        />
        <div className="space-y-2 mt-2">
          <MetricCard
            title="Heart Rate Measurement"
            icon={<Heart className="w-3 h-3" />}
            snap={snapshot.heartRate}
            renderParsed={(s) => <HeartRateValue snap={s} />}
            ocidPrefix="fitness.heart_rate"
          />
          <MetricCard
            title="Body Sensor Location"
            icon={<Cpu className="w-3 h-3" />}
            snap={snapshot.bodySensorLocation}
            renderParsed={(s) => <StringValue snap={s} />}
            ocidPrefix="fitness.body_sensor_location"
          />
        </div>
      </section>

      <section data-ocid="fitness.running_section">
        <SectionHeading
          icon={<Activity className="w-3 h-3" />}
          label="Running Speed & Cadence (0x1814)"
        />
        <div className="mt-2">
          <MetricCard
            title="RSC Measurement"
            icon={<Activity className="w-3 h-3" />}
            snap={snapshot.rscMeasurement}
            renderParsed={(s) => <RscValue snap={s} />}
            ocidPrefix="fitness.rsc"
          />
        </div>
      </section>

      <section data-ocid="fitness.cycling_section">
        <SectionHeading
          icon={<Bike className="w-3 h-3" />}
          label="Cycling Speed & Cadence (0x1816)"
        />
        <div className="mt-2">
          <MetricCard
            title="CSC Measurement"
            icon={<Bike className="w-3 h-3" />}
            snap={snapshot.cscMeasurement}
            renderParsed={(s) => <CscValue snap={s} />}
            ocidPrefix="fitness.csc"
          />
        </div>
      </section>

      <section data-ocid="fitness.battery_section">
        <SectionHeading
          icon={<Zap className="w-3 h-3" />}
          label="Battery (0x180F)"
        />
        <div className="mt-2">
          <MetricCard
            title="Battery Level"
            icon={<Zap className="w-3 h-3" />}
            snap={snapshot.battery}
            renderParsed={(s) => <BatteryValue snap={s} />}
            ocidPrefix="fitness.battery"
          />
        </div>
      </section>

      <section data-ocid="fitness.device_info_section">
        <SectionHeading
          icon={<Watch className="w-3 h-3" />}
          label="Device Information (0x180A)"
        />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
          {(
            [
              ["manufacturerName", "Manufacturer"],
              ["modelNumber", "Model Number"],
              ["firmwareRevision", "Firmware Rev"],
              ["hardwareRevision", "Hardware Rev"],
            ] as const
          ).map(([key, label]) => (
            <MetricCard
              key={key}
              title={label}
              icon={<Cpu className="w-3 h-3" />}
              snap={snapshot[key]}
              renderParsed={(s) => <StringValue snap={s} />}
              ocidPrefix={`fitness.${key}`}
            />
          ))}
        </div>
      </section>

      <VendorUnavailableSection />
    </div>
  );
}

// ─── Vendor-specific N/A section ───────────────────────────────────────────────

function VendorUnavailableSection() {
  return (
    <section className="mt-4" data-ocid="fitness.vendor_unavailable_section">
      <SectionHeading
        icon={<AlertCircle className="w-3 h-3" />}
        label="Vendor-Specific Data — Not Available via GATT"
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
        <NACard
          icon={<Activity className="w-3.5 h-3.5" />}
          title="Sleep Data"
          reason="Not part of standard Bluetooth GATT profiles — vendor SDK only (e.g. Fitbit/Garmin proprietary API)"
          ocid="fitness.sleep.not_available"
        />
        <NACard
          icon={<Zap className="w-3.5 h-3.5" />}
          title="Calories Burned"
          reason="Not part of standard Bluetooth GATT profiles — calculated by vendor firmware, not exposed as standard characteristic"
          ocid="fitness.calories.not_available"
        />
        <NACard
          icon={<Activity className="w-3.5 h-3.5" />}
          title="VO₂ Max"
          reason="Vendor-specific — only available through Garmin/Polar/Suunto proprietary APIs, not exposed via standard GATT"
          ocid="fitness.vo2max.not_available"
        />
        <NACard
          icon={<Heart className="w-3.5 h-3.5" />}
          title="Blood Oxygen (SpO₂)"
          reason="Vendor-specific or restricted — Continuous SpO₂ uses proprietary protocols; standard Pulse Oximeter GATT (0x1822) rarely implemented on consumer watches"
          ocid="fitness.spo2.not_available"
        />
        <NACard
          icon={<Activity className="w-3.5 h-3.5" />}
          title="Step Count History"
          reason="Step counters are stored in vendor cloud, not directly accessible via standard GATT characteristics"
          ocid="fitness.steps_history.not_available"
        />
        <NACard
          icon={<Cpu className="w-3.5 h-3.5" />}
          title="GPS Track / Route"
          reason="See GPS tab — Location & Navigation (0x1819) GATT service is rarely implemented; use browser Geolocation API instead"
          ocid="fitness.gps_track.not_available"
        />
      </div>
    </section>
  );
}

function SectionHeading({
  icon,
  label,
}: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex items-center gap-2 pb-1 border-b border-border/40">
      <span className="text-muted-foreground">{icon}</span>
      <span className="font-mono text-[10px] tracking-widest uppercase text-muted-foreground">
        {label}
      </span>
    </div>
  );
}
