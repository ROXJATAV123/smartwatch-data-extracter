import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useBluetoothStore } from "@/store/bluetooth-store";
import { useGpsStore } from "@/store/gps-store";
import type { GattCharacteristic, GattService, StreamEntry } from "@/types";
import {
  DEVICE_TYPE_LABELS,
  bytesToAscii,
  bytesToHexDump,
  detectDeviceType,
  formatOffset,
  formatRssi,
  formatTimestampMs,
  isWatchService,
  resolveUuidName,
} from "@/utils/data-format";
import {
  Bell,
  BellOff,
  Bluetooth,
  BluetoothOff,
  BluetoothSearching,
  ChevronDown,
  ChevronRight,
  Download,
  MapPin,
  Radio,
  RefreshCw,
  RotateCcw,
  Satellite,
  Trash2,
  Unplug,
} from "lucide-react";
import { useCallback, useState } from "react";

// ─── Status config ─────────────────────────────────────────────────────────────
const STATUS_CONFIG = {
  disconnected: {
    label: "DISCONNECTED",
    cls: "text-muted-foreground border-muted-foreground/40",
    dot: "bg-muted-foreground opacity-50",
  },
  connecting: {
    label: "CONNECTING",
    cls: "text-warning border-warning/40",
    dot: "bg-warning animate-pulse",
  },
  connected: {
    label: "CONNECTED",
    cls: "text-accent border-accent/40",
    dot: "bg-accent animate-pulse",
  },
} as const;

// ─── Main page ─────────────────────────────────────────────────────────────────
export default function BluetoothPage() {
  const {
    devices,
    activeDevice,
    services,
    isScanning,
    connectionStatus,
    streamEntries,
    activeNotifications,
    startScan,
    disconnect,
    clearStream,
    readCharacteristic,
    startNotify,
    stopNotify,
  } = useBluetoothStore();

  const { currentLocation, isTracking } = useGpsStore();

  const [scanError, setScanError] = useState<string | null>(null);
  const [selectedChar, setSelectedChar] = useState<GattCharacteristic | null>(
    null,
  );
  const [selectedSvcUuid, setSelectedSvcUuid] = useState<string | null>(null);
  const [hexView, setHexView] = useState<"hex" | "decimal" | "binary">("hex");
  const [expandedServices, setExpandedServices] = useState<Set<string>>(
    new Set(),
  );
  const [readingChar, setReadingChar] = useState<string | null>(null);
  const [notifyError, setNotifyError] = useState<string | null>(null);
  const [expandedStreamEntry, setExpandedStreamEntry] = useState<string | null>(
    null,
  );

  const handleScan = useCallback(async () => {
    setScanError(null);
    setNotifyError(null);
    try {
      await startScan();
    } catch (err) {
      setScanError(err instanceof Error ? err.message : "Scan failed");
    }
  }, [startScan]);

  const toggleService = (uuid: string) =>
    setExpandedServices((prev) => {
      const next = new Set(prev);
      next.has(uuid) ? next.delete(uuid) : next.add(uuid);
      return next;
    });

  const handleSelectChar = (ch: GattCharacteristic, svcUuid: string) => {
    setSelectedChar(ch);
    setSelectedSvcUuid(svcUuid);
  };

  const handleReadChar = useCallback(
    async (svcUuid: string, charUuid: string) => {
      setReadingChar(charUuid);
      try {
        await readCharacteristic(svcUuid, charUuid);
        const { services: svcs } = useBluetoothStore.getState();
        const svc = svcs.find((s) => s.uuid === svcUuid);
        const ch = svc?.characteristics.find((c) => c.uuid === charUuid);
        if (ch) setSelectedChar(ch);
      } catch {
        /* ignore */
      } finally {
        setReadingChar(null);
      }
    },
    [readCharacteristic],
  );

  const handleToggleNotify = useCallback(
    async (svcUuid: string, charUuid: string) => {
      setNotifyError(null);
      try {
        if (activeNotifications.has(charUuid)) {
          await stopNotify(charUuid);
        } else {
          await startNotify(svcUuid, charUuid);
        }
      } catch (err) {
        setNotifyError(
          err instanceof Error ? err.message : "Notification error",
        );
      }
    },
    [activeNotifications, startNotify, stopNotify],
  );

  const status = STATUS_CONFIG[connectionStatus];
  const deviceType = activeDevice
    ? detectDeviceType(activeDevice.name, activeDevice.serviceUuids)
    : "unknown";

  return (
    <div
      className="flex h-full min-h-0"
      style={{ height: "calc(100vh - 88px)" }}
    >
      {/* Left panel: GATT tree */}
      <aside className="w-72 shrink-0 border-r border-border flex flex-col bg-card overflow-hidden">
        <div className="panel-header flex items-center justify-between">
          <span>GATT Tree</span>
          <div className="flex gap-1">
            <button
              type="button"
              data-ocid="bt.scan_button"
              onClick={handleScan}
              disabled={isScanning}
              className="p-1 rounded-sm hover:bg-muted/50 text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
              title="Scan for devices"
            >
              {isScanning ? (
                <BluetoothSearching className="w-3.5 h-3.5 animate-pulse text-primary" />
              ) : (
                <RefreshCw className="w-3.5 h-3.5" />
              )}
            </button>
            {activeDevice?.connected && (
              <button
                type="button"
                data-ocid="bt.disconnect_button"
                onClick={disconnect}
                className="p-1 rounded-sm hover:bg-destructive/20 text-muted-foreground hover:text-destructive transition-colors"
                title="Disconnect"
              >
                <Unplug className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Scan + status */}
        <div className="px-3 py-2 border-b border-border space-y-2">
          <Button
            data-ocid="bt.scan_primary_button"
            onClick={handleScan}
            disabled={isScanning || connectionStatus === "connecting"}
            size="sm"
            className="w-full font-mono text-xs h-7 rounded-sm"
          >
            {isScanning ? (
              <>
                <BluetoothSearching className="w-3 h-3 mr-1 animate-pulse" />
                <span className="animate-pulse">Scanning for devices…</span>
                <ScanDots />
              </>
            ) : connectionStatus === "connecting" ? (
              <>
                <BluetoothSearching className="w-3 h-3 mr-1 animate-spin" />
                Connecting…
              </>
            ) : activeDevice?.connected ? (
              <>
                <Bluetooth className="w-3 h-3 mr-1" /> Re-scan Device
              </>
            ) : (
              <>
                <BluetoothSearching className="w-3 h-3 mr-1" /> Scan for Device
              </>
            )}
          </Button>

          {/* Connection status badge */}
          <div
            className={`flex items-center gap-1.5 px-2 py-1 rounded-sm border font-mono text-xs ${status.cls}`}
            data-ocid="bt.connection_status"
          >
            <span className={`w-1.5 h-1.5 rounded-full ${status.dot}`} />
            <span>STATUS: {status.label}</span>
          </div>

          {scanError && (
            <p
              className="font-mono text-xs text-destructive leading-tight"
              data-ocid="bt.error_state"
            >
              {scanError}
            </p>
          )}
          {notifyError && (
            <p
              className="font-mono text-xs text-destructive leading-tight"
              data-ocid="bt.notify_error_state"
            >
              {notifyError}
            </p>
          )}
        </div>

        {/* Device info banner */}
        {activeDevice && (
          <div className="px-3 py-2 border-b border-border bg-primary/5">
            <div className="flex items-center gap-1.5 mb-1">
              <span className="status-indicator bg-primary animate-pulse" />
              <span className="font-mono text-xs text-primary font-semibold truncate">
                {activeDevice.name}
              </span>
              <span className="ml-auto font-mono text-xs bg-muted/50 text-muted-foreground px-1.5 py-0.5 rounded-sm border border-border/50 shrink-0">
                {DEVICE_TYPE_LABELS[deviceType]}
              </span>
            </div>
            <p className="font-mono text-xs text-muted-foreground truncate">
              {activeDevice.id}
            </p>
            <p className="font-mono text-xs text-muted-foreground">
              {formatRssi(activeDevice.rssi)}
            </p>
          </div>
        )}

        {/* GATT services scroll */}
        <div className="flex-1 overflow-y-auto">
          {services.length === 0 && !activeDevice && (
            <div
              className="flex flex-col items-center justify-center h-full gap-3 py-8"
              data-ocid="bt.empty_state"
            >
              <BluetoothOff className="w-8 h-8 text-muted-foreground/40" />
              <p className="font-mono text-xs text-muted-foreground text-center px-4">
                No device connected.
                <br />
                Click Scan to discover BLE devices.
              </p>
            </div>
          )}

          {/* Discovering skeleton */}
          {services.length === 0 && activeDevice?.connected && (
            <div
              className="flex flex-col gap-0 py-2"
              data-ocid="bt.services_loading_state"
            >
              <p className="font-mono text-xs text-muted-foreground px-3 py-1.5 border-b border-border/30">
                Discovering services…
              </p>
              {[1, 2, 3].map((n) => (
                <div key={n} className="px-3 py-2 border-b border-border/30">
                  <div className="h-3 bg-muted/40 rounded-sm animate-pulse mb-1 w-24" />
                  <div className="h-2.5 bg-muted/30 rounded-sm animate-pulse w-40" />
                </div>
              ))}
            </div>
          )}

          {services.map((svc, si) => (
            <ServiceNode
              key={svc.uuid}
              service={svc}
              index={si}
              expanded={expandedServices.has(svc.uuid)}
              onToggle={() => toggleService(svc.uuid)}
              selectedChar={selectedChar}
              onSelectChar={(ch) => handleSelectChar(ch, svc.uuid)}
              activeNotifications={activeNotifications}
              onRead={(charUuid) => handleReadChar(svc.uuid, charUuid)}
              onToggleNotify={(charUuid) =>
                handleToggleNotify(svc.uuid, charUuid)
              }
              readingChar={readingChar}
            />
          ))}
        </div>
      </aside>

      {/* Centre panel: Hex dump + stream */}
      <div className="flex-1 flex flex-col min-w-0 border-r border-border">
        <div className="panel-header flex items-center justify-between">
          <span>
            {selectedChar
              ? `Hex Dump — ${
                  resolveUuidName(selectedChar.uuid) ??
                  selectedChar.uuid.slice(4, 8).toUpperCase()
                }`
              : "Hex Dump"}
          </span>
          <div className="flex items-center gap-1">
            {(["hex", "decimal", "binary"] as const).map((v) => (
              <button
                key={v}
                type="button"
                data-ocid={`bt.view_${v}_tab`}
                onClick={() => setHexView(v)}
                className={[
                  "font-mono text-xs px-2 py-0.5 rounded-sm border transition-colors capitalize",
                  hexView === v
                    ? "border-accent text-accent bg-accent/10"
                    : "border-border text-muted-foreground hover:text-foreground",
                ].join(" ")}
              >
                {v}
              </button>
            ))}
            {selectedChar &&
              selectedSvcUuid &&
              selectedChar.properties.includes("read") && (
                <button
                  type="button"
                  data-ocid="bt.read_button"
                  onClick={() =>
                    handleReadChar(selectedSvcUuid, selectedChar.uuid)
                  }
                  disabled={readingChar === selectedChar.uuid}
                  className="font-mono text-xs px-2 py-0.5 rounded-sm border border-primary/50 text-primary hover:bg-primary/10 transition-colors disabled:opacity-50 flex items-center gap-1"
                  title="Re-read characteristic"
                >
                  <RotateCcw
                    className={`w-3 h-3 ${
                      readingChar === selectedChar.uuid ? "animate-spin" : ""
                    }`}
                  />
                  Read
                </button>
              )}
          </div>
        </div>

        {selectedChar?.rawValue ? (
          <HexDumpView data={selectedChar.rawValue} mode={hexView} />
        ) : (
          <div
            className="flex-1 flex flex-col items-center justify-center gap-2"
            data-ocid="bt.hex_empty_state"
          >
            <span className="font-mono text-xs text-muted-foreground/50">
              Select a characteristic from the GATT tree
            </span>
          </div>
        )}

        {/* Live stream panel */}
        <div
          className="border-t border-border shrink-0"
          style={{ height: streamEntries.length > 0 ? "210px" : "auto" }}
        >
          <div className="panel-header flex items-center justify-between sticky top-0">
            <span className="flex items-center gap-1.5">
              <Bell className="w-3 h-3" />
              Live Stream
              {streamEntries.length > 0 && (
                <span className="font-mono text-xs text-accent">
                  ({streamEntries.length})
                </span>
              )}
              {activeNotifications.size > 0 && (
                <span className="font-mono text-xs bg-accent/10 text-accent border border-accent/30 px-1.5 rounded-sm">
                  {activeNotifications.size} sub
                </span>
              )}
            </span>
            <div className="flex items-center gap-1">
              {streamEntries.length > 0 && (
                <>
                  <button
                    type="button"
                    data-ocid="bt.export_stream_button"
                    onClick={() => exportStreamJson(streamEntries)}
                    className="p-1 hover:text-primary transition-colors"
                    title="Export stream as JSON"
                  >
                    <Download className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={clearStream}
                    className="p-1 hover:text-destructive transition-colors"
                    data-ocid="bt.clear_stream_button"
                    title="Clear stream"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </>
              )}
            </div>
          </div>

          {streamEntries.length === 0 ? (
            <div
              className="flex flex-col items-center justify-center gap-2 py-5"
              data-ocid="bt.stream_empty_state"
            >
              <Radio className="w-5 h-5 text-muted-foreground/30" />
              <p className="font-mono text-xs text-muted-foreground/50 text-center px-3">
                {activeNotifications.size > 0
                  ? "Subscribed — awaiting notifications…"
                  : "No data yet — subscribe to a characteristic to see live data"}
              </p>
            </div>
          ) : (
            <div className="overflow-y-auto" style={{ maxHeight: "165px" }}>
              {buildStreamRows(streamEntries).map(
                ({
                  key,
                  ocid,
                  time,
                  charShort,
                  charName,
                  svcShort,
                  byteCount,
                  hexStr,
                  decStr,
                  binStr,
                  asciiStr,
                  isWatch,
                }) => {
                  const entryKey = key;
                  const isExpanded = expandedStreamEntry === entryKey;
                  return (
                    <div key={key} data-ocid={ocid}>
                      <button
                        type="button"
                        className={[
                          "hex-row px-3 flex items-center gap-2 w-full text-left cursor-pointer hover:bg-muted/20 transition-colors",
                          isWatch
                            ? "border-l-2 border-primary/40"
                            : "border-l-2 border-accent/20",
                        ].join(" ")}
                        onClick={() =>
                          setExpandedStreamEntry(isExpanded ? null : entryKey)
                        }
                      >
                        <span className="hex-offset shrink-0">{time}</span>
                        <span
                          className={`font-mono text-xs shrink-0 ${
                            isWatch ? "text-primary" : "text-accent"
                          }`}
                        >
                          {charName ?? charShort}
                        </span>
                        <span className="font-mono text-[10px] text-muted-foreground shrink-0">
                          {svcShort} · {byteCount}B
                        </span>
                        <span
                          className={`font-mono text-xs truncate ${
                            isWatch ? "text-primary/80" : "text-accent/80"
                          }`}
                        >
                          {hexStr}
                        </span>
                      </button>
                      {isExpanded && (
                        <div className="px-3 py-2 bg-muted/10 border-b border-border/40 space-y-1">
                          <StreamDetail
                            label="HEX"
                            value={hexStr}
                            cls="text-accent"
                          />
                          <StreamDetail
                            label="DEC"
                            value={decStr}
                            cls="text-primary"
                          />
                          <StreamDetail
                            label="BIN"
                            value={binStr}
                            cls="text-[oklch(0.75_0.15_80)]"
                          />
                          <StreamDetail
                            label="ASCII"
                            value={asciiStr}
                            cls="text-muted-foreground"
                          />
                        </div>
                      )}
                    </div>
                  );
                },
              )}
            </div>
          )}
        </div>
      </div>

      {/* Right panel: device list + GPS mini-panel */}
      <aside className="w-56 shrink-0 flex flex-col bg-card overflow-hidden">
        {/* Scanned devices */}
        <div className="panel-header">Scanned Devices</div>
        <div
          className="overflow-y-auto border-b border-border"
          style={{ maxHeight: "180px" }}
        >
          {devices.length === 0 ? (
            <div
              className="p-3 font-mono text-xs text-muted-foreground"
              data-ocid="bt.devices_empty_state"
            >
              No devices yet.
            </div>
          ) : (
            buildDeviceRows(devices).map(
              ({ key, ocid, dev, deviceType: dt, connected }) => (
                <div
                  key={key}
                  data-ocid={ocid}
                  className={[
                    "px-3 py-2 border-b border-border/40 cursor-default",
                    connected ? "bg-primary/5" : "hover:bg-muted/20",
                  ].join(" ")}
                >
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`status-indicator ${
                        connected
                          ? "bg-primary animate-pulse"
                          : "bg-muted-foreground opacity-40"
                      }`}
                    />
                    <span className="font-mono text-xs text-foreground truncate font-semibold">
                      {dev.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="font-mono text-xs text-muted-foreground truncate">
                      {dev.id.slice(0, 12)}…
                    </span>
                  </div>
                  <div className="flex items-center gap-1 mt-0.5">
                    <Badge
                      variant="outline"
                      className="font-mono text-xs h-4 px-1 border-border/50 text-muted-foreground"
                    >
                      {dt}
                    </Badge>
                    {connected && (
                      <Badge
                        variant="outline"
                        className="font-mono text-xs border-primary/40 text-primary h-4 px-1"
                      >
                        ON
                      </Badge>
                    )}
                  </div>
                </div>
              ),
            )
          )}
        </div>

        {/* GPS mini-panel */}
        <div className="panel-header flex items-center gap-1.5">
          <MapPin className="w-3 h-3" />
          GPS
          <span
            className={`ml-auto status-indicator ${
              isTracking
                ? "bg-accent animate-pulse"
                : "bg-muted-foreground opacity-40"
            }`}
          />
        </div>
        <div className="flex-1 overflow-y-auto" data-ocid="bt.gps_panel">
          {currentLocation ? (
            <div className="p-3 space-y-2">
              <GpsMiniRow
                label="LAT"
                value={currentLocation.lat.toFixed(6)}
                unit="°"
              />
              <GpsMiniRow
                label="LNG"
                value={currentLocation.lng.toFixed(6)}
                unit="°"
              />
              <GpsMiniRow
                label="ACC"
                value={currentLocation.accuracy.toFixed(1)}
                unit="m"
              />
              {currentLocation.altitude !== null && (
                <GpsMiniRow
                  label="ALT"
                  value={currentLocation.altitude.toFixed(1)}
                  unit="m"
                />
              )}
              {currentLocation.speed !== null && (
                <GpsMiniRow
                  label="SPD"
                  value={(currentLocation.speed * 3.6).toFixed(1)}
                  unit="km/h"
                />
              )}
              <div className="border-t border-border/40 pt-2 mt-2">
                <GpsMiniRawBytes
                  lat={currentLocation.lat}
                  lng={currentLocation.lng}
                />
              </div>
            </div>
          ) : (
            <div
              className="flex flex-col items-center justify-center h-full gap-2 py-8"
              data-ocid="bt.gps_empty_state"
            >
              <Satellite className="w-6 h-6 text-muted-foreground/40" />
              <p className="font-mono text-xs text-muted-foreground text-center px-3">
                Switch to GPS tab to start tracking.
              </p>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}

// ─── Stream export helper ─────────────────────────────────────────────────────
function exportStreamJson(entries: StreamEntry[]) {
  const payload = entries.map((e) => ({
    timestamp: new Date(e.timestamp).toISOString(),
    serviceUuid: e.serviceUuid,
    characteristicUuid: e.characteristicUuid,
    bytes: Array.from(e.rawValue),
    hex: Array.from(e.rawValue)
      .map((b) => b.toString(16).padStart(2, "0").toUpperCase())
      .join(" "),
  }));
  const blob = new Blob([JSON.stringify(payload, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `ble-stream-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Pre-built row arrays ──────────────────────────────────────────────────────

function buildStreamRows(entries: StreamEntry[]) {
  const rows: Array<{
    key: string;
    ocid: string;
    time: string;
    charShort: string;
    charName: string | null;
    svcShort: string;
    byteCount: number;
    hexStr: string;
    decStr: string;
    binStr: string;
    asciiStr: string;
    isWatch: boolean;
  }> = [];
  for (let i = 0; i < Math.min(50, entries.length); i++) {
    const entry = entries[i];
    const bytes = Array.from(entry.rawValue);
    rows.push({
      key: `sr${entry.timestamp}-${i}`,
      ocid: `bt.stream.item.${i + 1}`,
      time: formatTimestampMs(entry.timestamp),
      charShort: entry.characteristicUuid.slice(4, 8).toUpperCase(),
      charName: resolveUuidName(entry.characteristicUuid),
      svcShort: entry.serviceUuid.slice(4, 8).toUpperCase(),
      byteCount: bytes.length,
      hexStr: bytes
        .map((b) => b.toString(16).padStart(2, "0").toUpperCase())
        .join(" "),
      decStr: bytes.map((b) => b.toString()).join(" "),
      binStr: bytes.map((b) => b.toString(2).padStart(8, "0")).join(" "),
      asciiStr: bytesToAscii(bytes),
      isWatch: isWatchService(entry.serviceUuid),
    });
  }
  return rows;
}

function buildDeviceRows(devices: import("@/types").BluetoothDeviceInfo[]) {
  const rows: Array<{
    key: string;
    ocid: string;
    dev: import("@/types").BluetoothDeviceInfo;
    deviceType: string;
    connected: boolean;
  }> = [];
  for (let i = 0; i < devices.length; i++) {
    const dev = devices[i];
    rows.push({
      key: `dev-${dev.id}`,
      ocid: `bt.device.item.${i + 1}`,
      dev,
      deviceType:
        DEVICE_TYPE_LABELS[detectDeviceType(dev.name, dev.serviceUuids)],
      connected: dev.connected,
    });
  }
  return rows;
}

// ─── StreamDetail ──────────────────────────────────────────────────────────────
function StreamDetail({
  label,
  value,
  cls,
}: { label: string; value: string; cls: string }) {
  return (
    <div className="flex items-start gap-2">
      <span className="font-mono text-[10px] text-muted-foreground w-9 shrink-0 pt-0.5">
        {label}
      </span>
      <span
        className={`font-mono text-[10px] break-all leading-relaxed ${cls}`}
      >
        {value}
      </span>
    </div>
  );
}

// ─── ScanDots ─────────────────────────────────────────────────────────────────
function ScanDots() {
  return (
    <span className="flex items-center gap-0.5 ml-1">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="w-1 h-1 rounded-full bg-current animate-bounce"
          style={{ animationDelay: `${i * 0.15}s` }}
        />
      ))}
    </span>
  );
}

// ─── ServiceNode ─────────────────────────────────────────────────────────────────
interface ServiceNodeProps {
  service: GattService;
  index: number;
  expanded: boolean;
  onToggle: () => void;
  selectedChar: GattCharacteristic | null;
  onSelectChar: (c: GattCharacteristic) => void;
  activeNotifications: Set<string>;
  onRead: (charUuid: string) => void;
  onToggleNotify: (charUuid: string) => void;
  readingChar: string | null;
}

function ServiceNode({
  service,
  index,
  expanded,
  onToggle,
  selectedChar,
  onSelectChar,
  activeNotifications,
  onRead,
  onToggleNotify,
  readingChar,
}: ServiceNodeProps) {
  const name = resolveUuidName(service.uuid);
  const isWatch = isWatchService(service.uuid);
  return (
    <div data-ocid={`bt.service.item.${index + 1}`}>
      <button
        type="button"
        onClick={onToggle}
        className="w-full flex items-center gap-1.5 px-3 py-2 hover:bg-muted/20 transition-colors gatt-service"
      >
        {expanded ? (
          <ChevronDown className="w-3 h-3 shrink-0" />
        ) : (
          <ChevronRight className="w-3 h-3 shrink-0" />
        )}
        <span
          className={`font-mono text-xs font-semibold ${
            isWatch ? "text-primary" : "text-accent"
          }`}
        >
          {service.uuid.slice(4, 8).toUpperCase()}
        </span>
        {name && (
          <span className="font-mono text-xs text-muted-foreground truncate">
            ({name})
          </span>
        )}
        {isWatch && (
          <span className="ml-auto font-mono text-[9px] bg-primary/10 text-primary border border-primary/20 px-1 rounded-sm shrink-0">
            ⌚
          </span>
        )}
      </button>
      {expanded &&
        service.characteristics.map((ch, ci) => (
          <CharacteristicRow
            key={ch.uuid}
            ch={ch}
            serviceIndex={index}
            charIndex={ci}
            isSelected={selectedChar?.uuid === ch.uuid}
            isNotifying={activeNotifications.has(ch.uuid)}
            isReading={readingChar === ch.uuid}
            onSelect={() => onSelectChar(ch)}
            onRead={() => onRead(ch.uuid)}
            onToggleNotify={() => onToggleNotify(ch.uuid)}
          />
        ))}
    </div>
  );
}

// ─── CharacteristicRow ───────────────────────────────────────────────────────────
interface CharRowProps {
  ch: GattCharacteristic;
  serviceIndex: number;
  charIndex: number;
  isSelected: boolean;
  isNotifying: boolean;
  isReading: boolean;
  onSelect: () => void;
  onRead: () => void;
  onToggleNotify: () => void;
}

function CharacteristicRow({
  ch,
  serviceIndex,
  charIndex,
  isSelected,
  isNotifying,
  isReading,
  onSelect,
  onRead,
  onToggleNotify,
}: CharRowProps) {
  const hasRead = ch.properties.includes("read");
  const hasNotify =
    ch.properties.includes("notify") || ch.properties.includes("indicate");
  return (
    <div
      data-ocid={`bt.characteristic.item.${serviceIndex + 1}.${charIndex + 1}`}
      className={[
        "gatt-characteristic transition-colors",
        isSelected ? "bg-accent/10" : "hover:bg-muted/20",
      ].join(" ")}
    >
      {/* Char label row (clickable to select) */}
      <button type="button" onClick={onSelect} className="w-full text-left">
        <div
          className={`font-mono text-xs ${
            isSelected ? "text-accent" : "text-foreground"
          }`}
        >
          {resolveUuidName(ch.uuid) ?? ch.uuid.slice(4, 8).toUpperCase()}
        </div>
        <div className="flex flex-wrap gap-0.5 mt-0.5">
          {ch.properties.map((p) => (
            <span
              key={p}
              className="font-mono text-xs bg-muted/50 text-muted-foreground px-1 rounded-sm"
            >
              {p}
            </span>
          ))}
        </div>
        {ch.rawValue && (
          <div className="font-mono text-xs text-accent/70 mt-0.5">
            {Array.from(ch.rawValue)
              .slice(0, 8)
              .map((b) => b.toString(16).padStart(2, "0").toUpperCase())
              .join(" ")}
            {ch.rawValue.length > 8 ? " …" : ""}
          </div>
        )}
      </button>
      {/* Action buttons */}
      {(hasRead || hasNotify) && (
        <div className="flex gap-1 mt-1">
          {hasRead && (
            <button
              type="button"
              data-ocid={`bt.read_char.${serviceIndex + 1}.${charIndex + 1}`}
              onClick={(e) => {
                e.stopPropagation();
                onRead();
              }}
              disabled={isReading}
              className="font-mono text-xs px-1.5 py-0.5 border border-primary/40 text-primary hover:bg-primary/10 rounded-sm transition-colors disabled:opacity-50 flex items-center gap-0.5"
            >
              <RotateCcw
                className={`w-2.5 h-2.5 ${isReading ? "animate-spin" : ""}`}
              />
              Read
            </button>
          )}
          {hasNotify && (
            <button
              type="button"
              data-ocid={`bt.notify_char.${serviceIndex + 1}.${charIndex + 1}`}
              onClick={(e) => {
                e.stopPropagation();
                onToggleNotify();
              }}
              className={[
                "font-mono text-xs px-1.5 py-0.5 rounded-sm border transition-colors flex items-center gap-0.5",
                isNotifying
                  ? "border-accent/50 text-accent bg-accent/10"
                  : "border-border text-muted-foreground hover:text-foreground",
              ].join(" ")}
            >
              {isNotifying ? (
                <>
                  <BellOff className="w-2.5 h-2.5" /> Stop
                </>
              ) : (
                <>
                  <Bell className="w-2.5 h-2.5" /> Notify
                </>
              )}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

// ─── HexDumpView ─────────────────────────────────────────────────────────────────
interface HexDumpViewProps {
  data: Uint8Array;
  mode: "hex" | "decimal" | "binary";
}

function buildRowCells(row: ReturnType<typeof bytesToHexDump>[number]) {
  const cells: Array<{
    key: string;
    b: number;
    hex: string;
    dec: number;
    bin: string;
    sep: boolean;
  }> = [];
  for (let n = 0; n < row.bytes.length; n++) {
    cells.push({
      key: `c${row.offset + n}`,
      b: row.bytes[n],
      hex: row.hex[n],
      dec: row.decimal[n],
      bin: row.binary[n],
      sep: n === 7,
    });
  }
  return cells;
}

function buildAnalysisRows(data: Uint8Array) {
  const rows: Array<{
    key: string;
    ocid: string;
    offset: string;
    hexVal: string;
    decVal: number;
    binVal: string;
    asciiVal: string;
  }> = [];
  for (let n = 0; n < data.length; n++) {
    const b = data[n];
    rows.push({
      key: `ar${n}`,
      ocid: `bt.byterow.item.${n + 1}`,
      offset: formatOffset(n),
      hexVal: b.toString(16).padStart(2, "0").toUpperCase(),
      decVal: b,
      binVal: b.toString(2).padStart(8, "0"),
      asciiVal: b >= 0x20 && b < 0x7f ? String.fromCharCode(b) : ".",
    });
  }
  return rows;
}

function HexDumpView({ data, mode }: HexDumpViewProps) {
  const rows = bytesToHexDump(data);
  const analysisRows = buildAnalysisRows(data);
  const rowsWithCells = rows.map((row) => ({
    ...row,
    cells: buildRowCells(row),
  }));

  return (
    <div className="flex-1 overflow-auto font-mono text-xs">
      {/* Column header */}
      <div className="sticky top-0 bg-muted/60 border-b border-border flex items-center gap-0 px-3 py-1">
        <span className="hex-offset text-xs">Offset</span>
        <span className="flex-1 text-muted-foreground">
          00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F
        </span>
        <span className="w-20 text-right text-muted-foreground pr-2">
          ASCII
        </span>
      </div>

      {rowsWithCells.map((row) => (
        <div
          key={row.offset}
          className="hex-row px-3 flex items-start gap-0"
          data-ocid={`bt.hexrow.item.${row.offset}`}
        >
          <span className="hex-offset">{formatOffset(row.offset)}</span>
          <div className="flex-1 flex flex-wrap gap-x-1.5">
            {row.cells.map(({ key, b, hex, dec, bin, sep }) => {
              const val =
                mode === "hex"
                  ? hex
                  : mode === "decimal"
                    ? dec.toString().padStart(3, " ")
                    : bin;
              return (
                <span
                  key={key}
                  className={`hex-val ${sep ? "mr-2" : ""}`}
                  title={`hex:${hex} dec:${b} bin:${bin}`}
                >
                  {val}
                </span>
              );
            })}
          </div>
          <span className="hex-ascii w-20 text-right pr-2">
            {bytesToAscii(row.bytes)}
          </span>
        </div>
      ))}

      {/* Per-byte analysis table (only for small payloads) */}
      {data.length <= 64 && (
        <div className="border-t border-border mt-2">
          <div className="panel-header">Byte Analysis</div>
          <table className="w-full font-mono text-xs">
            <thead>
              <tr className="border-b border-border">
                {["Offset", "Hex", "Decimal", "Binary", "Char"].map((h) => (
                  <th
                    key={h}
                    className="px-3 py-1.5 text-left text-muted-foreground font-normal"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {analysisRows.map(
                ({ key, ocid, offset, hexVal, decVal, binVal, asciiVal }) => (
                  <tr
                    key={key}
                    className="border-b border-border/30 hover:bg-muted/20"
                    data-ocid={ocid}
                  >
                    <td className="px-3 py-1 text-muted-foreground">
                      {offset}
                    </td>
                    <td className="px-3 py-1 text-accent font-semibold">
                      {hexVal}
                    </td>
                    <td className="px-3 py-1 text-foreground">{decVal}</td>
                    <td className="px-3 py-1 text-primary">{binVal}</td>
                    <td className="px-3 py-1 text-muted-foreground">
                      {asciiVal}
                    </td>
                  </tr>
                ),
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ─── GPS mini-panel helpers ───────────────────────────────────────────────────────
function GpsMiniRow({
  label,
  value,
  unit,
}: { label: string; value: string; unit: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="font-mono text-xs text-muted-foreground">{label}</span>
      <span className="font-mono text-xs text-accent">
        {value}
        <span className="text-muted-foreground ml-0.5">{unit}</span>
      </span>
    </div>
  );
}

function GpsMiniRawBytes({ lat, lng }: { lat: number; lng: number }) {
  const entries: Array<{ key: string; label: string; hex: string }> = [];
  const buf = new ArrayBuffer(16);
  const dv = new DataView(buf);
  dv.setFloat64(0, lat, false);
  dv.setFloat64(8, lng, false);
  const bytes = Array.from(new Uint8Array(buf));
  for (let i = 0; i < 8; i++) {
    entries.push({
      key: `latb${i}`,
      label: `L${i}`,
      hex: bytes[i].toString(16).toUpperCase().padStart(2, "0"),
    });
  }
  for (let i = 0; i < 8; i++) {
    entries.push({
      key: `lngb${i}`,
      label: `G${i}`,
      hex: bytes[8 + i].toString(16).toUpperCase().padStart(2, "0"),
    });
  }
  return (
    <div>
      <p className="font-mono text-xs text-muted-foreground mb-1">Raw bytes</p>
      <div className="flex flex-wrap gap-1">
        {entries.map(({ key, label, hex }) => (
          <span key={key} className="hex-cell" title={label}>
            {hex}
          </span>
        ))}
      </div>
    </div>
  );
}
