import { Button } from "@/components/ui/button";
import { useGpsStore } from "@/store/gps-store";
import type { LocationPoint } from "@/types";
import { formatTimestamp, speedColorClass } from "@/utils/data-format";
import {
  Clock,
  Download,
  MapPin,
  Navigation,
  Play,
  RefreshCw,
  Satellite,
  StopCircle,
  Trash2,
} from "lucide-react";
import { useCallback, useMemo, useState } from "react";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function toDms(deg: number, isLat: boolean): string {
  const abs = Math.abs(deg);
  const d = Math.floor(abs);
  const mFull = (abs - d) * 60;
  const m = Math.floor(mFull);
  const s = ((mFull - m) * 60).toFixed(2);
  const dir = isLat ? (deg >= 0 ? "N" : "S") : deg >= 0 ? "E" : "W";
  return `${d}° ${m}' ${s}" ${dir}`;
}

function haversineMeters(a: LocationPoint, b: LocationPoint): number {
  const R = 6371000;
  const toRad = (x: number) => (x * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const sinDLat = Math.sin(dLat / 2);
  const sinDLng = Math.sin(dLng / 2);
  const h =
    sinDLat * sinDLat +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * sinDLng * sinDLng;
  return R * 2 * Math.asin(Math.sqrt(h));
}

function formatDist(meters: number): string {
  return meters < 1000
    ? `${meters.toFixed(1)}m`
    : `${(meters / 1000).toFixed(2)}km`;
}

function exportCsv(history: LocationPoint[]): void {
  const header =
    "Timestamp,Latitude_DD,Longitude_DD,Accuracy_m,Altitude_m,Speed_ms,Heading_deg,Distance_from_prev_m";
  const rows: string[] = [];
  for (let i = 0; i < history.length; i++) {
    const pt = history[i];
    const prev = i < history.length - 1 ? history[i + 1] : null;
    const dist = prev ? haversineMeters(prev, pt).toFixed(2) : "";
    rows.push(
      [
        new Date(pt.timestamp).toISOString(),
        pt.lat.toFixed(10),
        pt.lng.toFixed(10),
        pt.accuracy.toFixed(2),
        pt.altitude !== null ? pt.altitude.toFixed(2) : "",
        pt.speed !== null ? pt.speed.toFixed(2) : "",
        pt.heading !== null && pt.heading !== undefined
          ? pt.heading.toFixed(1)
          : "",
        dist,
      ].join(","),
    );
  }
  const blob = new Blob([[header, ...rows].join("\n")], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `gps-history-${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

type GpsStatus = "idle" | "requesting" | "active" | "denied";

function statusLabel(status: GpsStatus): string {
  switch (status) {
    case "active":
      return "ACTIVE";
    case "requesting":
      return "REQUESTING";
    case "denied":
      return "PERMISSION DENIED";
    default:
      return "IDLE";
  }
}

function statusColor(status: GpsStatus): string {
  switch (status) {
    case "active":
      return "text-accent";
    case "requesting":
      return "text-[oklch(0.75_0.15_80)]";
    case "denied":
      return "text-destructive";
    default:
      return "text-muted-foreground";
  }
}

function statusDot(status: GpsStatus): string {
  switch (status) {
    case "active":
      return "bg-accent animate-pulse";
    case "requesting":
      return "bg-[oklch(0.75_0.15_80)] animate-pulse";
    case "denied":
      return "bg-destructive";
    default:
      return "bg-muted-foreground opacity-40";
  }
}

// ─── IEEE 754 analysis ───────────────────────────────────────────────────────

interface BitEntry {
  key: string;
  val: string;
}
interface ByteEntry {
  key: string;
  hex: string;
  rawByte: number;
}
interface BitAnalysis {
  sign: string;
  exponentBits: BitEntry[];
  mantissaBits: BitEntry[];
  allBits: BitEntry[];
  byteEntries: ByteEntry[];
  exponentStr: string;
}

function floatToBitAnalysis(value: number): BitAnalysis {
  const buf = new ArrayBuffer(8);
  new DataView(buf).setFloat64(0, value, false);
  const rawBytes = Array.from(new Uint8Array(buf));
  const bits = rawBytes.map((b) => b.toString(2).padStart(8, "0")).join("");
  const sign = bits[0];
  const expStr = bits.slice(1, 12);
  const mantStr = bits.slice(12);
  const allStr = sign + expStr + mantStr;
  const exponentBits: BitEntry[] = [];
  for (let n = 0; n < expStr.length; n++)
    exponentBits.push({ key: `exp${n}`, val: expStr[n] });
  const mantissaBits: BitEntry[] = [];
  for (let n = 0; n < mantStr.length; n++)
    mantissaBits.push({ key: `mnt${n}`, val: mantStr[n] });
  const allBits: BitEntry[] = [];
  for (let n = 0; n < allStr.length; n++)
    allBits.push({ key: `all${n}`, val: allStr[n] });
  const byteEntries: ByteEntry[] = [];
  for (let n = 0; n < rawBytes.length; n++)
    byteEntries.push({
      key: `byte${n}`,
      hex: rawBytes[n].toString(16).toUpperCase().padStart(2, "0"),
      rawByte: rawBytes[n],
    });
  return {
    sign,
    exponentStr: expStr,
    exponentBits,
    mantissaBits,
    allBits,
    byteEntries,
  };
}

// ─── Hex dump cell builders ───────────────────────────────────────────────────

type GpsCellHex = { key: string; hex: string };
type GpsCellBin = { key: string; bin: string };

function buildGpsFieldCells(
  allBytes: number[],
  label: string,
  start: number,
  end: number,
): { hexCells: GpsCellHex[]; binCells: GpsCellBin[] } {
  const hexCells: GpsCellHex[] = [];
  const binCells: GpsCellBin[] = [];
  for (let n = start; n < end; n++) {
    hexCells.push({
      key: `${label}h${n}`,
      hex: allBytes[n].toString(16).toUpperCase().padStart(2, "0"),
    });
    binCells.push({
      key: `${label}b${n}`,
      bin: allBytes[n].toString(2).padStart(8, "0"),
    });
  }
  return { hexCells, binCells };
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function GpsPage() {
  const {
    currentLocation,
    locationHistory,
    isTracking,
    intervalSec,
    error,
    startTracking,
    stopTracking,
    setIntervalSec,
    clearHistory,
  } = useGpsStore();

  const [showRaw, setShowRaw] = useState(false);
  const [reqStatus, setReqStatus] = useState<GpsStatus>("idle");
  const [clearConfirm, setClearConfirm] = useState(false);

  // Derived GPS status
  const gpsStatus: GpsStatus = useMemo(() => {
    if (error?.toLowerCase().includes("denied")) return "denied";
    if (isTracking) return "active";
    if (reqStatus === "requesting") return "requesting";
    return "idle";
  }, [error, isTracking, reqStatus]);

  const handleToggle = useCallback(() => {
    if (isTracking) {
      stopTracking();
    } else {
      setReqStatus("requesting");
      startTracking();
    }
  }, [isTracking, startTracking, stopTracking]);

  const handleRequestOnce = useCallback(() => {
    if (!navigator.geolocation) return;
    setReqStatus("requesting");
    navigator.geolocation.getCurrentPosition(
      () => setReqStatus("idle"),
      () => setReqStatus("denied"),
      { enableHighAccuracy: true, timeout: 10000 },
    );
    startTracking();
    setTimeout(() => stopTracking(), 500);
  }, [startTracking, stopTracking]);

  const handleClearHistory = useCallback(() => {
    if (!clearConfirm) {
      setClearConfirm(true);
      setTimeout(() => setClearConfirm(false), 3000);
    } else {
      clearHistory();
      setClearConfirm(false);
    }
  }, [clearConfirm, clearHistory]);

  const coordinateBits = useMemo(() => {
    if (!currentLocation) return null;
    return {
      lat: floatToBitAnalysis(currentLocation.lat),
      lng: floatToBitAnalysis(currentLocation.lng),
    };
  }, [currentLocation]);

  // Max speed in km/h from history
  const maxSpeedKmh = useMemo(() => {
    let max = 0;
    for (const pt of locationHistory) {
      if (pt.speed !== null) {
        const kmh = pt.speed * 3.6;
        if (kmh > max) max = kmh;
      }
    }
    return max;
  }, [locationHistory]);

  const loc = currentLocation;

  return (
    <div
      className="flex h-full min-h-0"
      style={{ height: "calc(100vh - 88px)" }}
    >
      {/* LEFT: GPS controls + current fix */}
      <aside className="w-80 shrink-0 border-r border-border flex flex-col bg-card overflow-hidden">
        {/* Status header */}
        <div className="panel-header flex items-center justify-between">
          <span>GPS Status</span>
          <span
            className="flex items-center gap-1.5"
            data-ocid="gps.status_indicator"
          >
            <span
              className={`w-2 h-2 rounded-full shrink-0 ${statusDot(gpsStatus)}`}
            />
            <span className={`font-mono text-xs ${statusColor(gpsStatus)}`}>
              {statusLabel(gpsStatus)}
            </span>
          </span>
        </div>

        {/* Permission denied error card */}
        {gpsStatus === "denied" && (
          <div
            className="mx-3 mt-3 p-3 rounded-sm border border-destructive/40 bg-destructive/5"
            data-ocid="gps.permission_denied_card"
          >
            <p className="font-mono text-xs text-destructive font-semibold mb-1">
              📍 Location access denied
            </p>
            <p className="font-mono text-xs text-muted-foreground mb-2 leading-relaxed">
              Please allow location in your browser settings, then retry.
            </p>
            <button
              type="button"
              data-ocid="gps.retry_button"
              onClick={handleRequestOnce}
              className="flex items-center gap-1.5 font-mono text-xs px-2 py-1 border border-destructive/40 text-destructive hover:bg-destructive/10 rounded-sm transition-colors"
            >
              <RefreshCw className="w-3 h-3" /> Retry
            </button>
          </div>
        )}

        {/* Tracking controls */}
        <div className="px-3 py-3 border-b border-border space-y-2">
          <Button
            data-ocid="gps.request_once_button"
            onClick={handleRequestOnce}
            size="sm"
            variant="secondary"
            className="w-full font-mono text-xs h-7 rounded-sm"
            disabled={isTracking}
          >
            <MapPin className="w-3 h-3 mr-1" /> Request Location
          </Button>
          <Button
            data-ocid="gps.toggle_tracking_button"
            onClick={handleToggle}
            size="sm"
            className="w-full font-mono text-xs h-7 rounded-sm"
            variant={isTracking ? "destructive" : "default"}
          >
            {isTracking ? (
              <>
                <StopCircle className="w-3 h-3 mr-1" /> Stop Tracking
              </>
            ) : (
              <>
                <Play className="w-3 h-3 mr-1" /> Start Tracking
              </>
            )}
          </Button>

          <div className="flex items-center gap-2">
            <label htmlFor="gps-interval-select" className="gps-label shrink-0">
              Interval
            </label>
            <select
              id="gps-interval-select"
              data-ocid="gps.interval_select"
              value={intervalSec}
              onChange={(e) => setIntervalSec(Number(e.target.value))}
              className="flex-1 font-mono text-xs bg-input border border-border rounded-sm px-2 py-1 text-foreground"
            >
              {[1, 5, 10, 30].map((v) => (
                <option key={v} value={v}>
                  {v}s
                </option>
              ))}
            </select>
          </div>

          {error && gpsStatus !== "denied" && (
            <p
              className="font-mono text-xs text-destructive"
              data-ocid="gps.error_state"
            >
              {error}
            </p>
          )}
        </div>

        {/* Stats summary */}
        {locationHistory.length > 0 && (
          <div className="px-3 py-2 border-b border-border bg-muted/10 flex flex-wrap gap-x-4 gap-y-1">
            <StatChip
              label="POINTS"
              value={`${locationHistory.length}`}
              cls="text-foreground"
            />
            {maxSpeedKmh > 0 && (
              <StatChip
                label="MAX SPD"
                value={`${maxSpeedKmh.toFixed(1)} km/h`}
                cls={speedColorClass(maxSpeedKmh)}
              />
            )}
          </div>
        )}

        {/* Current fix */}
        {loc ? (
          <div className="px-3 py-3 border-b border-border space-y-2 overflow-y-auto">
            <CoordField
              label="LATITUDE"
              value={loc.lat}
              isLat
              ocid="gps.lat_value"
            />
            <CoordField
              label="LONGITUDE"
              value={loc.lng}
              isLat={false}
              ocid="gps.lng_value"
            />
            <GpsField
              label="ACCURACY"
              value={`${loc.accuracy.toFixed(1)} m`}
              ocid="gps.accuracy_value"
            />
            {loc.altitude !== null && loc.altitude !== undefined && (
              <GpsField
                label="ALTITUDE"
                value={`${loc.altitude.toFixed(1)} m`}
                ocid="gps.altitude_value"
              />
            )}
            {loc.speed !== null && loc.speed !== undefined && (
              <GpsField
                label="SPEED"
                value={`${(loc.speed * 3.6).toFixed(1)} km/h`}
                ocid="gps.speed_value"
              />
            )}
            {loc.heading !== null && loc.heading !== undefined && (
              <GpsField
                label="HEADING"
                value={`${loc.heading.toFixed(1)} °`}
                ocid="gps.heading_value"
              />
            )}
            <div
              className="flex items-center justify-between"
              data-ocid="gps.timestamp_value"
            >
              <span className="gps-label flex items-center gap-1">
                <Clock className="w-3 h-3" /> TIMESTAMP
              </span>
              <span className="font-mono text-xs text-muted-foreground">
                {new Date(loc.timestamp).toLocaleTimeString()}
              </span>
            </div>
          </div>
        ) : (
          <div
            className="flex flex-col items-center justify-center flex-1 gap-3 py-8"
            data-ocid="gps.empty_state"
          >
            <MapPin className="w-8 h-8 text-muted-foreground/40" />
            <p className="font-mono text-xs text-muted-foreground text-center px-4">
              No GPS fix yet.
              <br />
              Click Request Location or Start Tracking.
            </p>
          </div>
        )}

        {/* History footer */}
        <div className="px-3 py-2 border-t border-border mt-auto flex items-center justify-between">
          <span className="font-mono text-xs text-muted-foreground flex items-center gap-1">
            <Navigation className="w-3 h-3" />
            {locationHistory.length} pts
          </span>
          <div className="flex items-center gap-2">
            {locationHistory.length > 0 && (
              <button
                type="button"
                data-ocid="gps.export_button"
                onClick={() => exportCsv(locationHistory)}
                className="font-mono text-xs text-muted-foreground hover:text-accent transition-colors flex items-center gap-1"
              >
                <Download className="w-3 h-3" /> CSV
              </button>
            )}
            {locationHistory.length > 0 && (
              <button
                type="button"
                data-ocid="gps.clear_history_button"
                onClick={handleClearHistory}
                className={[
                  "font-mono text-xs transition-colors flex items-center gap-1",
                  clearConfirm
                    ? "text-destructive border border-destructive/40 px-1.5 py-0.5 rounded-sm bg-destructive/5 animate-pulse"
                    : "text-muted-foreground hover:text-destructive",
                ].join(" ")}
              >
                <Trash2 className="w-3 h-3" />
                {clearConfirm ? "Confirm?" : "Clear"}
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* CENTRE: bit-level coordinate analysis */}
      <div className="flex-1 flex flex-col min-w-0 border-r border-border">
        <div className="panel-header flex items-center justify-between">
          <span>Coordinate Bit Analysis — IEEE 754 Double</span>
          <button
            type="button"
            data-ocid="gps.raw_toggle"
            onClick={() => setShowRaw((v) => !v)}
            className={[
              "font-mono text-xs px-2 py-0.5 rounded-sm border transition-colors",
              showRaw
                ? "border-accent text-accent bg-accent/10"
                : "border-border text-muted-foreground hover:text-foreground",
            ].join(" ")}
          >
            {showRaw ? "SEGMENTED VIEW" : "RAW IEEE 754"}
          </button>
        </div>

        {coordinateBits ? (
          <div className="flex-1 overflow-auto p-3 space-y-4">
            <CoordBitPanel
              label="LATITUDE"
              coord={loc!.lat}
              bits={coordinateBits.lat}
              showRaw={showRaw}
            />
            <CoordBitPanel
              label="LONGITUDE"
              coord={loc!.lng}
              bits={coordinateBits.lng}
              showRaw={showRaw}
            />

            {loc && (
              <div>
                <div className="panel-header -mx-3 mb-2">
                  Full GPS Data Dump — 48 bytes
                </div>
                <GpsHexDump location={loc} />
              </div>
            )}
          </div>
        ) : (
          <div
            className="flex-1 flex items-center justify-center"
            data-ocid="gps.bits_empty_state"
          >
            <span className="font-mono text-xs text-muted-foreground/50">
              Awaiting GPS fix…
            </span>
          </div>
        )}
      </div>

      {/* RIGHT: location history table */}
      <aside className="w-[360px] shrink-0 flex flex-col bg-card overflow-hidden">
        <div className="panel-header flex items-center gap-1.5">
          <Satellite className="w-3 h-3" />
          <span>Location History</span>
          <span className="ml-auto font-mono text-xs text-muted-foreground">
            {Math.min(locationHistory.length, 100)} / 100
          </span>
        </div>
        {/* Table header */}
        <div className="px-3 py-1.5 border-b border-border bg-muted/20 grid grid-cols-[1fr_1fr_auto_auto_auto] gap-2">
          {["LAT", "LNG", "±ACC", "DIST", "TOTAL"].map((h) => (
            <span key={h} className="gps-label text-right">
              {h}
            </span>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto">
          {locationHistory.length === 0 ? (
            <div
              className="flex flex-col items-center justify-center gap-3 py-10"
              data-ocid="gps.history_empty_state"
            >
              <MapPin className="w-7 h-7 text-muted-foreground/30" />
              <p className="font-mono text-xs text-muted-foreground text-center px-4">
                Start tracking to record your path
              </p>
            </div>
          ) : (
            <HistoryTable history={locationHistory.slice(0, 100)} />
          )}
        </div>
      </aside>
    </div>
  );
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function StatChip({
  label,
  value,
  cls,
}: { label: string; value: string; cls: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="font-mono text-[10px] text-muted-foreground">
        {label}
      </span>
      <span className={`font-mono text-xs font-semibold ${cls}`}>{value}</span>
    </div>
  );
}

function GpsField({
  label,
  value,
  ocid,
}: { label: string; value: string; ocid: string }) {
  return (
    <div className="flex items-center justify-between" data-ocid={ocid}>
      <span className="gps-label">{label}</span>
      <span className="font-mono text-xs text-foreground">{value}</span>
    </div>
  );
}

function CoordField({
  label,
  value,
  isLat,
  ocid,
}: { label: string; value: number; isLat: boolean; ocid: string }) {
  return (
    <div className="space-y-0.5" data-ocid={ocid}>
      <div className="flex items-center justify-between">
        <span className="gps-label">{label} DD</span>
        <span className="font-mono text-xs text-accent">
          {value.toFixed(8)}°
        </span>
      </div>
      <div className="flex items-center justify-between">
        <span className="gps-label">{label} DMS</span>
        <span className="font-mono text-xs text-muted-foreground">
          {toDms(value, isLat)}
        </span>
      </div>
    </div>
  );
}

function CoordBitPanel({
  label,
  coord,
  bits,
  showRaw,
}: { label: string; coord: number; bits: BitAnalysis; showRaw: boolean }) {
  return (
    <div className="border border-border rounded-sm overflow-hidden">
      <div className="bg-muted/40 px-3 py-1.5 flex items-center justify-between border-b border-border">
        <span className="gps-label">{label}</span>
        <span className="font-mono text-sm text-accent">
          {coord.toFixed(10)}
        </span>
      </div>
      {/* Bit legend */}
      <div className="px-3 pt-2 pb-1 flex items-center gap-3 font-mono text-xs border-b border-border/40">
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded-sm bg-destructive/20 border border-destructive/30 inline-block" />
          <span className="text-muted-foreground">Sign (1)</span>
        </span>
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded-sm bg-primary/15 border border-primary/25 inline-block" />
          <span className="text-muted-foreground">Exponent (11)</span>
        </span>
        <span className="flex items-center gap-1">
          <span className="w-3 h-3 rounded-sm bg-accent/20 border border-accent/30 inline-block" />
          <span className="text-muted-foreground">Mantissa (52)</span>
        </span>
      </div>
      {showRaw ? (
        <div className="p-3 space-y-2">
          {/* Full 64-bit string — segmented with color */}
          <div className="flex items-start gap-0.5 flex-wrap font-mono text-xs leading-6">
            <span
              title="Sign bit"
              className="px-1 py-0.5 rounded-sm bg-destructive/20 text-destructive border border-destructive/30"
            >
              {bits.sign}
            </span>
            <span className="px-0.5 text-muted-foreground/40">·</span>
            {bits.exponentBits.map(({ key, val }) => (
              <span
                key={key}
                className="px-0.5 py-0.5 rounded-sm bg-primary/15 text-primary border border-primary/25"
              >
                {val}
              </span>
            ))}
            <span className="px-0.5 text-muted-foreground/40">·</span>
            {bits.mantissaBits.map(({ key, val }) => (
              <span
                key={key}
                className={`px-0.5 py-0.5 rounded-sm ${
                  val === "1"
                    ? "bg-accent/20 text-accent border border-accent/30"
                    : "text-muted-foreground/40"
                }`}
              >
                {val}
              </span>
            ))}
          </div>
          {/* Decoded fields */}
          <div className="flex gap-3 font-mono text-xs text-muted-foreground border-t border-border/40 pt-2">
            <span>
              Sign:{" "}
              <span className="text-destructive">
                {bits.sign === "0" ? "+" : "−"}
              </span>
            </span>
            <span>
              Exp: <span className="text-primary">{bits.exponentStr}</span>{" "}
              <span className="text-muted-foreground/60">
                (raw={Number.parseInt(bits.exponentStr, 2)}, bias=
                {Number.parseInt(bits.exponentStr, 2) - 1023})
              </span>
            </span>
          </div>
        </div>
      ) : (
        <div className="p-3 space-y-2">
          {/* Byte cells */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {bits.byteEntries.map(({ key, hex, rawByte }) => (
              <span
                key={key}
                className="hex-val"
                title={`0x${hex} = ${rawByte} = ${rawByte.toString(2).padStart(8, "0")}`}
              >
                {hex}
              </span>
            ))}
          </div>
          {/* Bit grid */}
          <div className="flex items-center gap-px flex-wrap font-mono text-xs">
            {bits.allBits.map(({ key, val }, n) => (
              <span
                key={key}
                className={`w-3 h-4 flex items-center justify-center rounded-sm ${
                  n === 0
                    ? "bg-destructive/20 text-destructive"
                    : n < 12
                      ? "bg-primary/15 text-primary"
                      : val === "1"
                        ? "bg-accent/20 text-accent"
                        : "text-muted-foreground/30"
                }`}
              >
                {val}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function GpsHexDump({ location }: { location: LocationPoint }) {
  const buf = new ArrayBuffer(48);
  const dv = new DataView(buf);
  dv.setFloat64(0, location.lat, false);
  dv.setFloat64(8, location.lng, false);
  dv.setFloat64(16, location.accuracy, false);
  dv.setFloat64(24, location.altitude ?? 0, false);
  dv.setFloat64(32, location.speed ?? 0, false);
  dv.setFloat64(40, location.timestamp / 1000, false);
  const allBytes = Array.from(new Uint8Array(buf));

  const fieldDefs = [
    { label: "LAT", start: 0, end: 8, ocid: 1, even: true },
    { label: "LNG", start: 8, end: 16, ocid: 2, even: false },
    { label: "ACC", start: 16, end: 24, ocid: 3, even: true },
    { label: "ALT", start: 24, end: 32, ocid: 4, even: false },
    { label: "SPD", start: 32, end: 40, ocid: 5, even: true },
    { label: "TS", start: 40, end: 48, ocid: 6, even: false },
  ];

  const fields = fieldDefs.map(({ label, start, end, ocid, even }) => ({
    label,
    start,
    ocid,
    even,
    ...buildGpsFieldCells(allBytes, label, start, end),
  }));

  return (
    <div className="font-mono text-xs border border-border rounded-sm overflow-hidden">
      {fields.map(({ label, start, ocid, even, hexCells, binCells }) => (
        <div
          key={label}
          className={`hex-row px-3 flex items-center gap-3 ${
            even ? "bg-muted/10" : ""
          }`}
          data-ocid={`gps.dump.item.${ocid}`}
        >
          <span className="w-8 gps-label shrink-0">{label}</span>
          <span className="hex-offset">
            {start.toString(16).padStart(4, "0")}
          </span>
          <div className="flex gap-1">
            {hexCells.map(({ key, hex }) => (
              <span key={key} className="hex-val">
                {hex}
              </span>
            ))}
          </div>
          <div className="flex gap-0.5 ml-2">
            {binCells.map(({ key, bin }) => (
              <span key={key} className="text-muted-foreground/60 text-[10px]">
                {bin}
              </span>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function HistoryTable({ history }: { history: LocationPoint[] }) {
  // Pre-compute cumulative distances
  interface HistoryRowData {
    rowKey: string;
    point: LocationPoint;
    index: number;
    hopDist: number | null;
    cumulDist: number;
    speedKmh: number | null;
  }

  const rows: HistoryRowData[] = [];
  let cumulative = 0;
  for (let i = 0; i < history.length; i++) {
    const prev = i < history.length - 1 ? history[i + 1] : null;
    const hopDist = prev ? haversineMeters(prev, history[i]) : null;
    if (hopDist !== null) cumulative += hopDist;
    rows.push({
      rowKey: `hr${i}`,
      point: history[i],
      index: i,
      hopDist,
      cumulDist: cumulative,
      speedKmh:
        history[i].speed !== null ? (history[i].speed ?? 0) * 3.6 : null,
    });
  }

  return (
    <div>
      {rows.map(({ rowKey, point, index, hopDist, cumulDist, speedKmh }) => (
        <div
          key={rowKey}
          className={`px-3 py-1.5 border-b border-border/40 hover:bg-muted/20 ${
            index % 2 === 1 ? "bg-muted/5" : ""
          }`}
          data-ocid={`gps.history.item.${index + 1}`}
        >
          {/* Row 1: lat / lng */}
          <div className="grid grid-cols-2 gap-1">
            <span className="font-mono text-xs text-accent truncate">
              {point.lat.toFixed(6)}
            </span>
            <span className="font-mono text-xs text-primary truncate text-right">
              {point.lng.toFixed(6)}
            </span>
          </div>
          {/* Row 2: DMS lat */}
          <div className="font-mono text-[10px] text-muted-foreground/70 truncate">
            {toDms(point.lat, true)} / {toDms(point.lng, false)}
          </div>
          {/* Row 3: accuracy + speed + time */}
          <div className="grid grid-cols-[auto_auto_1fr] gap-2 mt-0.5 items-center">
            <span className="font-mono text-[10px] text-muted-foreground">
              ±{point.accuracy.toFixed(0)}m
            </span>
            {speedKmh !== null ? (
              <span
                className={`font-mono text-[10px] ${speedColorClass(speedKmh)}`}
              >
                {speedKmh.toFixed(1)} km/h
              </span>
            ) : (
              <span className="font-mono text-[10px] text-muted-foreground/40">
                —
              </span>
            )}
            <span className="font-mono text-[10px] text-muted-foreground text-right">
              {formatTimestamp(point.timestamp)}
            </span>
          </div>
          {/* Row 4: hop distance + cumulative */}
          <div className="flex items-center gap-2 mt-0.5">
            {hopDist !== null ? (
              <span className="font-mono text-[10px] text-[oklch(0.75_0.15_80)]">
                Δ{formatDist(hopDist)}
              </span>
            ) : (
              <span className="font-mono text-[10px] text-muted-foreground/40">
                —
              </span>
            )}
            {cumulDist > 0 && (
              <span className="font-mono text-[10px] text-muted-foreground">
                ∑{formatDist(cumulDist)}
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
