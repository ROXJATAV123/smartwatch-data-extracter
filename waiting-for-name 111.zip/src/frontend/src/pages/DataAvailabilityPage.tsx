import {
  CheckCircle2,
  Info,
  Lock,
  ShieldAlert,
  Smartphone,
  XCircle,
} from "lucide-react";

interface AvailableItem {
  name: string;
  nameHi: string;
  icon: React.ReactNode;
  method: string;
  methodHi: string;
  status: "available";
  detail: string;
  detailHi: string;
}

interface UnavailableItem {
  name: string;
  nameHi: string;
  icon: React.ReactNode;
  reason: string;
  reasonHi: string;
  status: "unavailable";
  detail: string;
  detailHi: string;
}

type DataItem = AvailableItem | UnavailableItem;

const AVAILABLE_DATA: AvailableItem[] = [
  {
    name: "Bluetooth (BLE)",
    nameHi: "ब्लूटूथ",
    icon: <span className="text-lg">📡</span>,
    status: "available",
    method: "Web Bluetooth API",
    methodHi: "वेब ब्लूटूथ API",
    detail:
      "Browser connects directly to BLE devices. GATT services, characteristics, and raw byte values are fully readable.",
    detailHi:
      "Browser सीधे BLE device से connect होता है। GATT services, characteristics और raw bytes पूरी तरह readable हैं।",
  },
  {
    name: "GPS / Location",
    nameHi: "GPS / लोकेशन",
    icon: <span className="text-lg">📍</span>,
    status: "available",
    method: "Geolocation API",
    methodHi: "जियोलोकेशन API",
    detail:
      "Browser reads live GPS coordinates (lat, lng, altitude, speed, heading) with user permission. All values are real device data.",
    detailHi:
      "Browser real GPS coordinates (lat, lng, altitude, speed, heading) पढ़ता है — user की permission से। सारा data real device का है।",
  },
  {
    name: "File Upload & Byte Analysis",
    nameHi: "फ़ाइल अपलोड",
    icon: <span className="text-lg">📂</span>,
    status: "available",
    method: "File API / FileReader",
    methodHi: "File API / FileReader",
    detail:
      "User selects any file (JSON, CSV, image, audio, video, PDF, binary). Browser reads it as ArrayBuffer and displays the first 256 bytes in hex, decimal, and binary with byte offsets and ASCII representation. File type is detected from magic bytes.",
    detailHi:
      "User कोई भी file select करता है (JSON, CSV, image, audio, video, PDF, binary)। Browser उसे ArrayBuffer में read करता है और पहले 256 bytes को hex, decimal, binary format में byte offsets और ASCII के साथ दिखाता है। Magic bytes से file type detect होता है।",
  },
  {
    name: "Phone Sensors (Motion, Orientation)",
    nameHi: "फोन सेंसर",
    icon: <span className="text-lg">📱</span>,
    status: "available",
    method: "DeviceMotionEvent / DeviceOrientationEvent",
    methodHi: "DeviceMotionEvent / DeviceOrientationEvent",
    detail:
      "Browser reads accelerometer (X/Y/Z m/s²), gyroscope rotation rate (alpha/beta/gamma deg/s), and device orientation in real time. iOS requires explicit permission. Float values are shown with IEEE 754 hex and binary bit patterns.",
    detailHi:
      "Browser accelerometer (X/Y/Z m/s²), gyroscope rotation rate और device orientation real-time में read करता है। iOS पर explicit permission चाहिए। Float values IEEE 754 hex और binary के साथ दिखते हैं।",
  },
  {
    name: "Battery Status",
    nameHi: "बैटरी स्टेटस",
    icon: <span className="text-lg">🔋</span>,
    status: "available",
    method: "Battery Status API",
    methodHi: "Battery Status API",
    detail:
      "Charge level (%), charging state, charging time, and discharging time. Not available in all browsers (Firefox removed it; Chrome supports it).",
    detailHi:
      "Charge level (%), charging state, charging time और discharging time मिलता है। सभी browsers में available नहीं (Firefox ने remove किया; Chrome support करता है)।",
  },
  {
    name: "Network Information",
    nameHi: "नेटवर्क जानकारी",
    icon: <span className="text-lg">📶</span>,
    status: "available",
    method: "NetworkInformation API",
    methodHi: "NetworkInformation API",
    detail:
      "Connection type (wifi/4g/3g), effective type, downlink speed (Mbps), RTT (ms), and saveData mode. Available in Chrome/Android browsers.",
    detailHi:
      "Connection type (wifi/4g/3g), effective type, downlink speed (Mbps), RTT (ms) और saveData mode। Chrome/Android browsers में available है।",
  },
  {
    name: "Screen & Device Info",
    nameHi: "स्क्रीन और डिवाइस जानकारी",
    icon: <span className="text-lg">🖥️</span>,
    status: "available",
    method: "window.screen / navigator",
    methodHi: "window.screen / navigator",
    detail:
      "Screen dimensions, color depth, pixel depth, orientation type/angle, devicePixelRatio. Plus userAgent, platform, language, CPU cores, device memory, and touch points — all readable from any browser.",
    detailHi:
      "Screen dimensions, color depth, pixel depth, orientation, devicePixelRatio। साथ में userAgent, platform, language, CPU cores, device memory और touch points — सभी किसी भी browser में readable हैं।",
  },
];

const UNAVAILABLE_DATA: UnavailableItem[] = [
  {
    name: "Video Files (from gallery/storage)",
    nameHi: "वीडियो फ़ाइलें (gallery से)",
    icon: <span className="text-lg">🎬</span>,
    status: "unavailable",
    reason: "OS-level storage — browser cannot browse file system",
    reasonHi: "OS-level storage — browser file system browse नहीं कर सकता",
    detail:
      "Video files in the device's DCIM or media folder are not accessible without the user manually picking them via a file picker. Use the File Upload tab to analyse a video file you select manually.",
    detailHi:
      "Device की DCIM या media folder में stored videos browser directly access नहीं कर सकता। File Upload tab में manually file select करके analyse किया जा सकता है।",
  },
  {
    name: "Audio Files (from music library)",
    nameHi: "ऑडियो फ़ाइलें (music से)",
    icon: <span className="text-lg">🎵</span>,
    status: "unavailable",
    reason: "OS-level storage — browser cannot browse file system",
    reasonHi: "OS-level storage — browser file system browse नहीं कर सकता",
    detail:
      "Audio recordings and music files in protected OS directories are not browseable by the browser. Only manually selected files via file picker can be read — use the File Upload tab.",
    detailHi:
      "Audio recordings और music files OS की protected directories में हैं। Browser उन्हें browse नहीं कर सकता। File Upload tab में manually select करें।",
  },
  {
    name: "Camera Roll / Gallery Images",
    nameHi: "कैमरा रोल / गैलरी",
    icon: <span className="text-lg">🖼️</span>,
    status: "unavailable",
    reason: "OS-level storage — browser cannot browse file system",
    reasonHi: "OS-level storage — browser file system browse नहीं कर सकता",
    detail:
      "Photos stored in the gallery are not accessible to the browser without user action. The File Upload tab lets you pick an image and see its full byte analysis including dimensions.",
    detailHi:
      "Gallery में stored photos browser को directly accessible नहीं हैं। File Upload tab में image pick करके उसकी byte analysis और dimensions देख सकते हैं।",
  },
  {
    name: "Call Logs",
    nameHi: "कॉल लॉग्स",
    icon: <span className="text-lg">📞</span>,
    status: "unavailable",
    reason: "Privacy-protected OS data — requires native app",
    reasonHi: "Privacy-protected OS data — native app ज़रूरी है",
    detail:
      "Call history is stored in a protected telephony database on the OS. Web browsers have zero access to telephony APIs — a native Android/iOS app with READ_CALL_LOG permission is required.",
    detailHi:
      "Call history OS के protected telephony database में होती है। Web browser के पास telephony API का कोई access नहीं होता — इसके लिए native Android/iOS app चाहिए जिसे READ_CALL_LOG permission मिली हो।",
  },
  {
    name: "SMS / Message Logs",
    nameHi: "SMS / मैसेज लॉग्स",
    icon: <span className="text-lg">💬</span>,
    status: "unavailable",
    reason: "Privacy-protected OS data — requires native app",
    reasonHi: "Privacy-protected OS data — native app ज़रूरी है",
    detail:
      "SMS and messaging databases are protected OS resources. Browsers have no API to read SMS history. A native app with READ_SMS permission or a backend SMS gateway is needed.",
    detailHi:
      "SMS और messaging databases OS के protected resources हैं। Browser के पास SMS history read करने का कोई API नहीं है। इसके लिए READ_SMS permission वाला native app या SMS gateway चाहिए।",
  },
  {
    name: "App Notifications (from other apps)",
    nameHi: "नोटिफिकेशन्स (दूसरे apps की)",
    icon: <span className="text-lg">🔔</span>,
    status: "unavailable",
    reason: "OS notification stream — no browser read API",
    reasonHi: "OS notification stream — browser में read करने की API नहीं",
    detail:
      "The Web Notifications API allows the browser to show its own notifications, but it cannot read or intercept notifications from other apps. That requires Android's NotificationListenerService or iOS equivalents — native apps only.",
    detailHi:
      "Web Notifications API browser को notifications दिखाने देती है, लेकिन दूसरे apps की notifications read या intercept नहीं कर सकती। इसके लिए Android का NotificationListenerService या iOS equivalent चाहिए — सिर्फ native apps।",
  },
  {
    name: "Contacts / Address Book",
    nameHi: "कॉन्टैक्ट्स / एड्रेस बुक",
    icon: <span className="text-lg">👤</span>,
    status: "unavailable",
    reason: "Privacy-protected OS data — browser has no access",
    reasonHi: "Privacy-protected OS data — browser की कोई access नहीं",
    detail:
      "The Contact Picker API exists but is highly restricted: it only allows picking individual contacts with explicit user selection per use — bulk contact export is not possible from a browser.",
    detailHi:
      "Contact Picker API है लेकिन बहुत restricted है: user एक-एक contact manually select करे तभी मिलता है — browser से bulk contact export possible नहीं है।",
  },
  {
    name: "Installed Apps List",
    nameHi: "इंस्टॉल्ड Apps की लिस्ट",
    icon: <span className="text-lg">📋</span>,
    status: "unavailable",
    reason: "OS-level data — browser sandboxed from app registry",
    reasonHi: "OS-level data — browser app registry से sandboxed है",
    detail:
      "Browsers cannot enumerate installed applications on the device. There is no Web API for this. Only native apps with appropriate OS permissions can list installed packages.",
    detailHi:
      "Browser device पर installed applications की list नहीं देख सकता। इसके लिए कोई Web API नहीं है। सिर्फ native apps ही installed packages list कर सकते हैं।",
  },
];

function AvailableCard({ item }: { item: AvailableItem }) {
  return (
    <div
      className="border border-accent/30 rounded-sm bg-accent/5 p-4 space-y-2"
      data-ocid={`availability.available.${item.name.toLowerCase().replace(/[^a-z0-9]/g, "_")}_card`}
    >
      <div className="flex items-center gap-2">
        {item.icon}
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-mono text-sm font-semibold text-foreground">
              {item.name}
            </span>
            <span className="font-mono text-xs text-muted-foreground">
              {item.nameHi}
            </span>
          </div>
          <div className="flex items-center gap-1.5 mt-0.5">
            <CheckCircle2 className="w-3 h-3 text-accent shrink-0" />
            <span className="font-mono text-xs text-accent">{item.method}</span>
            <span className="font-mono text-xs text-muted-foreground">
              · {item.methodHi}
            </span>
          </div>
        </div>
      </div>
      <p className="font-mono text-xs text-foreground/80 leading-relaxed">
        {item.detail}
      </p>
      <p className="font-mono text-xs text-muted-foreground leading-relaxed border-t border-border/40 pt-2">
        {item.detailHi}
      </p>
    </div>
  );
}

function UnavailableCard({ item }: { item: UnavailableItem }) {
  return (
    <div
      className="border border-border rounded-sm bg-card p-4 space-y-2"
      data-ocid={`availability.unavailable.${item.name.toLowerCase().replace(/[^a-z0-9]/g, "_")}_card`}
    >
      <div className="flex items-center gap-2">
        {item.icon}
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-mono text-sm font-semibold text-foreground">
              {item.name}
            </span>
            <span className="font-mono text-xs text-muted-foreground">
              {item.nameHi}
            </span>
          </div>
          <div className="flex items-center gap-1.5 mt-0.5">
            <XCircle className="w-3 h-3 text-destructive shrink-0" />
            <span className="font-mono text-xs text-destructive">
              {item.reason}
            </span>
          </div>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="font-mono text-xs text-muted-foreground">
              {item.reasonHi}
            </span>
          </div>
        </div>
      </div>
      <p className="font-mono text-xs text-foreground/70 leading-relaxed">
        {item.detail}
      </p>
      <p className="font-mono text-xs text-muted-foreground/80 leading-relaxed border-t border-border/40 pt-2">
        {item.detailHi}
      </p>
    </div>
  );
}

export default function DataAvailabilityPage() {
  return (
    <div
      className="min-h-0 overflow-auto"
      style={{ height: "calc(100vh - 88px)" }}
    >
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-8">
        {/* Page header */}
        <div
          className="border border-border rounded-sm bg-muted/20 p-4 flex items-start gap-3"
          data-ocid="availability.info_banner"
        >
          <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-mono text-xs text-foreground leading-relaxed">
              This app uses only{" "}
              <span className="text-primary font-semibold">
                real browser APIs
              </span>{" "}
              — no simulated or demo data. The table below shows exactly what
              your browser can access and what it cannot, along with the
              technical reasons why.
            </p>
            <p className="font-mono text-xs text-muted-foreground leading-relaxed">
              यह app सिर्फ{" "}
              <span className="text-primary font-semibold">
                real browser APIs
              </span>{" "}
              use करती है — कोई simulated या demo data नहीं। नीचे दी गई list में
              clearly बताया गया है कि browser क्या access कर सकता है और क्या नहीं, और
              technical reasons भी दिए गए हैं।
            </p>
          </div>
        </div>

        {/* Why section */}
        <div
          className="border border-border/60 rounded-sm p-4 bg-card flex items-start gap-3"
          data-ocid="availability.why_section"
        >
          <ShieldAlert className="w-4 h-4 text-[oklch(0.75_0.15_80)] shrink-0 mt-0.5" />
          <div className="space-y-1.5">
            <p className="font-mono text-xs font-semibold text-foreground uppercase tracking-wider">
              Why can't a browser access everything?
            </p>
            <p className="font-mono text-xs text-foreground/80 leading-relaxed">
              Browsers run in a strict security sandbox. They are deliberately
              prevented from reading the file system, telephony, SMS, or
              notification databases to protect user privacy. These restrictions
              exist at the OS level and apply to all web apps equally.
            </p>
            <p className="font-mono text-xs text-muted-foreground leading-relaxed">
              Browser एक strict security sandbox में चलता है। File system,
              telephony, SMS, या notifications database को read करने से
              deliberately रोका जाता है — यह user की privacy protect करने के लिए है।
              ये restrictions OS level पर होती हैं और सभी web apps पर equally apply
              होती हैं।
            </p>
            <div className="flex items-center gap-2 mt-2 pt-2 border-t border-border/40">
              <Smartphone className="w-3.5 h-3.5 text-primary shrink-0" />
              <p className="font-mono text-xs text-primary">
                For full device data access, a native Android / iOS app is
                required.
              </p>
            </div>
            <p className="font-mono text-xs text-muted-foreground">
              Full device data access के लिए native Android / iOS app ज़रूरी है।
            </p>
          </div>
        </div>

        {/* Available data */}
        <section data-ocid="availability.available_section">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle2 className="w-4 h-4 text-accent" />
            <h2 className="font-mono text-xs uppercase tracking-widest text-accent font-semibold">
              Available — Real Data
            </h2>
            <span className="font-mono text-xs text-muted-foreground">
              · उपलब्ध (Real Data)
            </span>
            <span className="ml-auto font-mono text-xs bg-accent/10 text-accent border border-accent/30 px-2 py-0.5 rounded-sm">
              {AVAILABLE_DATA.length} sources
            </span>
          </div>
          <div className="space-y-3">
            {AVAILABLE_DATA.map((item) => (
              <AvailableCard key={item.name} item={item} />
            ))}
          </div>
        </section>

        {/* Unavailable data */}
        <section data-ocid="availability.unavailable_section">
          <div className="flex items-center gap-2 mb-3">
            <Lock className="w-4 h-4 text-muted-foreground" />
            <h2 className="font-mono text-xs uppercase tracking-widest text-muted-foreground font-semibold">
              Not Available in Browser
            </h2>
            <span className="font-mono text-xs text-muted-foreground/70">
              · Browser में उपलब्ध नहीं
            </span>
            <span className="ml-auto font-mono text-xs bg-muted/40 text-muted-foreground border border-border/60 px-2 py-0.5 rounded-sm">
              {UNAVAILABLE_DATA.length} blocked
            </span>
          </div>
          <div className="space-y-3">
            {UNAVAILABLE_DATA.map((item) => (
              <UnavailableCard key={item.name} item={item} />
            ))}
          </div>
        </section>

        {/* Summary table */}
        <section data-ocid="availability.summary_table">
          <h2 className="font-mono text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-3">
            Quick Reference / त्वरित संदर्भ
          </h2>
          <div className="border border-border rounded-sm overflow-hidden">
            <div className="grid grid-cols-[1fr_1fr_auto] gap-0 bg-muted/30 px-3 py-1.5 border-b border-border">
              <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
                Data Type
              </span>
              <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
                Method / Reason
              </span>
              <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
                Status
              </span>
            </div>
            {(AVAILABLE_DATA as DataItem[])
              .concat(UNAVAILABLE_DATA)
              .map((item, i) => (
                <div
                  key={item.name}
                  className={`grid grid-cols-[1fr_1fr_auto] gap-2 items-start px-3 py-2 border-b border-border/40 ${
                    i % 2 === 1 ? "bg-muted/5" : ""
                  }`}
                  data-ocid={`availability.table.item.${i + 1}`}
                >
                  <div className="flex items-center gap-1.5 min-w-0">
                    {item.icon}
                    <span className="font-mono text-xs text-foreground truncate">
                      {item.name}
                    </span>
                  </div>
                  <span className="font-mono text-xs text-muted-foreground leading-tight">
                    {item.status === "available" ? item.method : item.reason}
                  </span>
                  <span
                    className={`font-mono text-xs font-semibold shrink-0 ${
                      item.status === "available"
                        ? "text-accent"
                        : "text-destructive/70"
                    }`}
                  >
                    {item.status === "available" ? "✓ YES" : "✗ NO"}
                  </span>
                </div>
              ))}
          </div>
        </section>
      </div>
    </div>
  );
}
