import { useFileStore } from "@/store/file-store";
import {
  bytesToAscii,
  bytesToHexDump,
  formatOffset,
} from "@/utils/data-format";
import { FileText, HardDrive, UploadCloud, X } from "lucide-react";
import { useCallback, useRef, useState } from "react";

const MAX_PREVIEW_BYTES = 256;
const BYTES_PER_ROW = 16;

interface FileMeta {
  name: string;
  size: number;
  type: string;
  lastModified: number;
  detectedType: string;
  imageWidth?: number;
  imageHeight?: number;
  previewUrl?: string;
}

const MAGIC_SIGNATURES: Array<{
  name: string;
  magic: number[];
  offset?: number;
}> = [
  { name: "JPEG", magic: [0xff, 0xd8, 0xff] },
  { name: "PNG", magic: [0x89, 0x50, 0x4e, 0x47] },
  { name: "GIF", magic: [0x47, 0x49, 0x46, 0x38] },
  { name: "PDF", magic: [0x25, 0x50, 0x44, 0x46] },
  { name: "ZIP", magic: [0x50, 0x4b, 0x03, 0x04] },
  { name: "MP3", magic: [0xff, 0xfb] },
  { name: "MP3 (ID3)", magic: [0x49, 0x44, 0x33] },
  { name: "MP4", magic: [0x66, 0x74, 0x79, 0x70], offset: 4 },
  { name: "WAV", magic: [0x52, 0x49, 0x46, 0x46] },
  { name: "BMP", magic: [0x42, 0x4d] },
  { name: "WEBP", magic: [0x57, 0x45, 0x42, 0x50], offset: 8 },
  { name: "FLAC", magic: [0x66, 0x4c, 0x61, 0x43] },
  { name: "OGG", magic: [0x4f, 0x67, 0x67, 0x53] },
];

function detectMagicType(bytes: Uint8Array): string {
  for (const sig of MAGIC_SIGNATURES) {
    const offset = sig.offset ?? 0;
    const match = sig.magic.every((b, i) => bytes[offset + i] === b);
    if (match) return sig.name;
  }
  const slice = bytes.slice(0, 32);
  const printable = Array.from(slice).filter(
    (b) => b >= 0x20 && b < 0x7f,
  ).length;
  if (printable / slice.length > 0.85) return "Text/ASCII";
  return "Unknown Binary";
}

function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(2)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

type HexViewMode = "hex" | "decimal" | "binary";

function HexDumpViewer({ data }: { data: Uint8Array }) {
  const [mode, setMode] = useState<HexViewMode>("hex");
  const rows = bytesToHexDump(data, BYTES_PER_ROW);

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-1">
        {(["hex", "decimal", "binary"] as HexViewMode[]).map((m) => (
          <button
            key={m}
            type="button"
            data-ocid={`file_upload.hex_mode_${m}`}
            onClick={() => setMode(m)}
            className={[
              "font-mono text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-sm border transition-colors",
              mode === m
                ? "border-primary/60 text-primary bg-primary/10"
                : "border-border/40 text-muted-foreground hover:border-border hover:text-foreground",
            ].join(" ")}
          >
            {m}
          </button>
        ))}
      </div>
      <div className="overflow-x-auto rounded-sm border border-border/60 bg-background">
        <table className="w-full min-w-max text-left" aria-label="Hex dump">
          <thead>
            <tr className="bg-muted/30 border-b border-border">
              <th className="font-mono text-[10px] text-muted-foreground px-2 py-1 w-20 uppercase tracking-widest">
                Offset
              </th>
              <th className="font-mono text-[10px] text-muted-foreground px-2 py-1 uppercase tracking-widest">
                {mode === "hex"
                  ? "Hex"
                  : mode === "decimal"
                    ? "Decimal"
                    : "Binary"}{" "}
                (16 bytes / row)
              </th>
              <th className="font-mono text-[10px] text-muted-foreground px-2 py-1 uppercase tracking-widest">
                ASCII
              </th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr
                key={row.offset}
                className="border-b border-border/20 hover:bg-muted/10 transition-colors"
              >
                <td className="font-mono text-xs text-muted-foreground/70 px-2 py-0.5 select-none">
                  {formatOffset(row.offset)}
                </td>
                <td className="px-2 py-0.5">
                  <div className="flex flex-wrap gap-x-1 gap-y-0">
                    {mode === "hex" &&
                      row.hex.map((h, hi) => (
                        <span key={`${row.offset}-h-${hi}`} className="hex-val">
                          {h}
                        </span>
                      ))}
                    {mode === "decimal" &&
                      row.decimal.map((d, di) => (
                        <span
                          key={`${row.offset}-d-${di}`}
                          className="font-mono text-xs text-chart-2 px-0.5"
                        >
                          {d.toString().padStart(3, " ")}
                        </span>
                      ))}
                    {mode === "binary" &&
                      row.bytes.map((b, bi) => (
                        <span
                          key={`${row.offset}-b-${bi}`}
                          className="font-mono text-[9px] px-0.5"
                          style={
                            {
                              color: "oklch(var(--accent-image))",
                            } as React.CSSProperties
                          }
                        >
                          {b.toString(2).padStart(8, "0")}
                        </span>
                      ))}
                  </div>
                </td>
                <td className="px-2 py-0.5">
                  <span className="hex-ascii">{bytesToAscii(row.bytes)}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

async function readFileData(
  file: File,
): Promise<{ meta: FileMeta; preview: Uint8Array }> {
  const buffer = await file.arrayBuffer();
  const allBytes = new Uint8Array(buffer);
  const preview = allBytes.slice(0, MAX_PREVIEW_BYTES);
  const detected = detectMagicType(allBytes);
  const fileMeta: FileMeta = {
    name: file.name,
    size: file.size,
    type: file.type || "application/octet-stream",
    lastModified: file.lastModified,
    detectedType: detected,
  };
  if (
    file.type.startsWith("image/") ||
    detected === "JPEG" ||
    detected === "PNG" ||
    detected === "GIF" ||
    detected === "BMP"
  ) {
    fileMeta.previewUrl = URL.createObjectURL(file);
    await new Promise<void>((resolve) => {
      const img = new Image();
      img.onload = () => {
        fileMeta.imageWidth = img.naturalWidth;
        fileMeta.imageHeight = img.naturalHeight;
        resolve();
      };
      img.onerror = () => resolve();
      img.src = fileMeta.previewUrl as string;
    });
  }
  return { meta: fileMeta, preview };
}

export default function FileUploadPage() {
  const {
    name,
    size,
    type,
    lastModified,
    detectedType,
    imageWidth,
    imageHeight,
    setFileData,
    clearFileData,
  } = useFileStore();
  const meta: FileMeta | null =
    name !== null &&
    size !== null &&
    type !== null &&
    lastModified !== null &&
    detectedType !== null
      ? {
          name,
          size,
          type,
          lastModified,
          detectedType,
          imageWidth,
          imageHeight,
        }
      : null;

  const [previewBytes, setPreviewBytes] = useState<Uint8Array | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  function clearFile() {
    clearFileData();
    setPreviewBytes(null);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  async function applyFile(file: File) {
    setIsLoading(true);
    const { meta: m, preview } = await readFileData(file);
    setFileData({
      name: m.name,
      size: m.size,
      type: m.type,
      lastModified: m.lastModified,
      detectedType: m.detectedType,
      imageWidth: m.imageWidth,
      imageHeight: m.imageHeight,
      previewBytes: Array.from(preview),
    });
    setPreviewBytes(preview);
    if (m.previewUrl) setPreviewUrl(m.previewUrl);
    setIsLoading(false);
  }

  const handleDrop = useCallback(
    async (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragOver(false);
      const file = e.dataTransfer.files[0];
      if (!file) return;
      setIsLoading(true);
      const { meta: m, preview } = await readFileData(file);
      setFileData({
        name: m.name,
        size: m.size,
        type: m.type,
        lastModified: m.lastModified,
        detectedType: m.detectedType,
        imageWidth: m.imageWidth,
        imageHeight: m.imageHeight,
        previewBytes: Array.from(preview),
      });
      setPreviewBytes(preview);
      if (m.previewUrl) setPreviewUrl(m.previewUrl);
      setIsLoading(false);
    },
    [setFileData],
  );

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    await applyFile(file);
  }

  const accentStyle = {
    color: "oklch(var(--accent-image))",
  } as React.CSSProperties;
  const accentBorderBg = {
    borderColor: "oklch(var(--accent-image) / 0.3)",
    backgroundColor: "oklch(var(--accent-image) / 0.05)",
  } as React.CSSProperties;

  return (
    <div
      className="min-h-0 overflow-auto"
      style={{ height: "calc(100vh - 88px)" }}
      data-ocid="file_upload.page"
    >
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-5">
        {/* Header */}
        <div className="flex items-center gap-2">
          <HardDrive className="w-4 h-4" style={accentStyle} />
          <h1 className="font-mono text-sm font-semibold text-foreground uppercase tracking-widest">
            File Upload & Byte Analysis
          </h1>
          <span className="font-mono text-xs text-muted-foreground">
            · फ़ाइल अपलोड
          </span>
        </div>

        {/* Drop zone */}
        {!meta && (
          <button
            type="button"
            data-ocid="file_upload.dropzone"
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragOver(true);
            }}
            onDragLeave={() => setIsDragOver(false)}
            onDrop={handleDrop}
            className={[
              "w-full border-2 border-dashed rounded-sm flex flex-col items-center justify-center gap-3 py-14 transition-colors cursor-pointer",
              isDragOver
                ? "border-border bg-muted/10"
                : "border-border/60 hover:border-border hover:bg-muted/10",
            ].join(" ")}
            style={isDragOver ? accentBorderBg : undefined}
            onClick={() => inputRef.current?.click()}
            aria-label="Upload file"
          >
            <UploadCloud
              className="w-10 h-10 transition-colors"
              style={isDragOver ? accentStyle : undefined}
            />
            <div className="text-center space-y-1">
              <p className="font-mono text-xs text-foreground">
                Drag & drop any file here, or{" "}
                <span
                  className="underline underline-offset-2"
                  style={accentStyle}
                >
                  click to browse
                </span>
              </p>
              <p className="font-mono text-[10px] text-muted-foreground">
                JSON, CSV, Image, Audio, Video, PDF, Binary — कोई भी file
              </p>
            </div>
          </button>
        )}

        {/* Hidden file input */}
        <input
          ref={inputRef}
          type="file"
          accept="*/*"
          className="hidden"
          data-ocid="file_upload.input"
          onChange={handleFileChange}
        />

        {/* Loading state */}
        {isLoading && (
          <div
            data-ocid="file_upload.loading_state"
            className="flex items-center justify-center gap-2 py-10 border border-border rounded-sm bg-card"
          >
            <span className="font-mono text-xs text-muted-foreground animate-pulse">
              Reading file bytes...
            </span>
          </div>
        )}

        {/* File results */}
        {meta && previewBytes && !isLoading && (
          <div className="space-y-4" data-ocid="file_upload.results_panel">
            {/* File header + clear */}
            <div
              className="flex items-center justify-between gap-2 border rounded-sm px-3 py-2"
              style={accentBorderBg}
            >
              <div className="flex items-center gap-2 min-w-0">
                <FileText className="w-4 h-4 shrink-0" style={accentStyle} />
                <span className="font-mono text-sm text-foreground truncate font-semibold">
                  {meta.name}
                </span>
                <span className="font-mono text-xs text-muted-foreground shrink-0">
                  {formatBytes(meta.size)}
                </span>
              </div>
              <button
                type="button"
                data-ocid="file_upload.close_button"
                onClick={clearFile}
                className="text-muted-foreground hover:text-foreground transition-colors"
                aria-label="Clear file"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Metadata table */}
            <section data-ocid="file_upload.metadata_section">
              <div className="panel-header">
                File Metadata · फ़ाइल की जानकारी
              </div>
              <div className="border border-border rounded-sm border-t-0 overflow-hidden">
                {(
                  [
                    ["Name", meta.name],
                    [
                      "Size",
                      `${meta.size.toLocaleString()} bytes (${formatBytes(meta.size)})`,
                    ],
                    ["MIME Type", meta.type],
                    [
                      "Last Modified",
                      new Date(meta.lastModified).toLocaleString(),
                    ],
                    ["Detected Type (magic bytes)", meta.detectedType],
                    ...(meta.imageWidth
                      ? [
                          [
                            "Dimensions",
                            `${meta.imageWidth} × ${meta.imageHeight} px`,
                          ],
                        ]
                      : []),
                  ] as [string, string][]
                ).map(([label, value], i) => (
                  <div
                    key={label}
                    className={`flex items-start gap-2 px-3 py-1.5 border-b border-border/30 ${
                      i % 2 === 1 ? "bg-muted/10" : ""
                    }`}
                  >
                    <span className="font-mono text-xs text-muted-foreground w-52 shrink-0">
                      {label}
                    </span>
                    <span className="font-mono text-xs text-foreground break-all">
                      {value}
                    </span>
                  </div>
                ))}
              </div>
            </section>

            {/* Image preview */}
            {previewUrl && (
              <section data-ocid="file_upload.image_preview_section">
                <div className="panel-header">Image Preview · इमेज प्रिव्यू</div>
                <div className="border border-border border-t-0 rounded-sm rounded-t-none bg-muted/10 p-4 flex justify-center">
                  <img
                    src={previewUrl}
                    alt={meta.name}
                    className="max-h-48 max-w-full rounded-sm border border-border/40 object-contain"
                  />
                </div>
              </section>
            )}

            {/* Byte summary */}
            <div className="flex flex-wrap gap-3">
              {(
                [
                  ["Total Bytes", meta.size.toLocaleString()],
                  [
                    "Displayed Bytes",
                    Math.min(meta.size, MAX_PREVIEW_BYTES).toString(),
                  ],
                  [
                    "Remaining Bytes",
                    Math.max(0, meta.size - MAX_PREVIEW_BYTES).toLocaleString(),
                  ],
                  [
                    "Rows",
                    Math.ceil(
                      Math.min(meta.size, MAX_PREVIEW_BYTES) / BYTES_PER_ROW,
                    ).toString(),
                  ],
                ] as [string, string][]
              ).map(([label, value]) => (
                <div
                  key={label}
                  className="border border-border/50 rounded-sm bg-card px-3 py-1.5"
                >
                  <div className="font-mono text-[10px] text-muted-foreground uppercase tracking-widest">
                    {label}
                  </div>
                  <div className="font-mono text-sm text-foreground font-semibold">
                    {value}
                  </div>
                </div>
              ))}
            </div>

            {/* Hex dump */}
            <section data-ocid="file_upload.hex_dump_section">
              <div className="panel-header">
                Byte Dump — First {Math.min(meta.size, MAX_PREVIEW_BYTES)} bytes
                · बाइट डंप
              </div>
              <div className="border border-border border-t-0 rounded-sm rounded-t-none p-3">
                <HexDumpViewer data={previewBytes} />
              </div>
            </section>

            {/* Upload new file */}
            <button
              type="button"
              data-ocid="file_upload.upload_button"
              onClick={() => {
                clearFile();
                setTimeout(() => inputRef.current?.click(), 50);
              }}
              className="w-full font-mono text-xs border border-border/60 hover:border-border text-muted-foreground hover:text-foreground py-2 rounded-sm transition-colors"
            >
              Upload Another File · दूसरी File Upload करें
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
