import type { Tab } from "@/App";
import { useBluetoothStore } from "@/store/bluetooth-store";
import { useFileStore } from "@/store/file-store";
import { useFitnessStore } from "@/store/fitness-store";
import { useGpsStore } from "@/store/gps-store";
import { useSensorStore } from "@/store/sensor-store";
import {
  Activity,
  Bluetooth,
  Download,
  HardDrive,
  Heart,
  Info,
  MapPin,
} from "lucide-react";
import { useState } from "react";

interface LayoutProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
  children: React.ReactNode;
  btConnected?: boolean;
  gpsTracking?: boolean;
}

// Per-tab accent color
const TAB_ACCENT: Record<Tab, string> = {
  bluetooth: "oklch(0.55 0.15 247)",
  gps: "oklch(0.75 0.18 142)",
  "file-upload": "oklch(0.68 0.21 310)",
  sensors: "oklch(0.72 0.17 84)",
  fitness: "oklch(0.62 0.22 15)",
  "data-availability": "oklch(0.65 0.2 295)",
};

export function Layout({
  activeTab,
  onTabChange,
  children,
  btConnected,
  gpsTracking,
}: LayoutProps) {
  const [exportedFlash, setExportedFlash] = useState(false);

  const { activeDevice, services, streamEntries } = useBluetoothStore();
  const { currentLocation, locationHistory, isTracking } = useGpsStore();
  const { snapshot: fitnessSnapshot } = useFitnessStore();
  const { motion, orientation, battery, network, screen, deviceInfo } =
    useSensorStore();
  const {
    name: fileName,
    size: fileSize,
    type: fileType,
    lastModified,
    detectedType,
    imageWidth,
    imageHeight,
    previewBytes: filePreviewBytes,
  } = useFileStore();

  const hasData =
    !!activeDevice?.connected ||
    locationHistory.length > 0 ||
    fileName !== null;

  function handleExportAll() {
    const payload = {
      exportedAt: new Date().toISOString(),
      bluetooth: {
        connectedDevice: activeDevice,
        services,
        streamEntries: streamEntries.map((e) => ({
          timestamp: new Date(e.timestamp).toISOString(),
          serviceUuid: e.serviceUuid,
          characteristicUuid: e.characteristicUuid,
          bytes: Array.from(e.rawValue),
          hex: Array.from(e.rawValue)
            .map((b) => b.toString(16).padStart(2, "0").toUpperCase())
            .join(" "),
        })),
      },
      gps: {
        currentLocation,
        history: locationHistory,
        trackingActive: isTracking,
      },
      sensors: {
        capturedAt: new Date().toISOString(),
        motion: motion
          ? {
              acceleration: motion.acceleration,
              accelerationIncludingGravity: motion.accelerationIncludingGravity,
              rotationRate: motion.rotationRate,
              interval: motion.interval,
            }
          : null,
        orientation: orientation
          ? {
              alpha: orientation.alpha,
              beta: orientation.beta,
              gamma: orientation.gamma,
              absolute: orientation.absolute,
            }
          : null,
        battery: battery
          ? {
              charging: battery.charging,
              chargingTime: battery.chargingTime,
              dischargingTime: battery.dischargingTime,
              level: battery.level,
            }
          : null,
        network: network
          ? {
              type: network.type,
              effectiveType: network.effectiveType,
              downlink: network.downlink,
              rtt: network.rtt,
              saveData: network.saveData,
            }
          : null,
        screen,
        deviceInfo,
      },
      fitness: Object.fromEntries(
        (
          [
            "heartRate",
            "battery",
            "rscMeasurement",
            "cscMeasurement",
            "manufacturerName",
            "modelNumber",
            "firmwareRevision",
            "hardwareRevision",
          ] as const
        ).map((key) => {
          const snap = fitnessSnapshot[key];
          return [
            key,
            {
              parsed_value: snap.parsed,
              raw_bytes: snap.rawBytes,
              updated_at: snap.updatedAt,
              error: snap.error,
            },
          ];
        }),
      ),
      fileUpload:
        fileName !== null
          ? {
              name: fileName,
              size: fileSize,
              type: fileType,
              lastModified: lastModified
                ? new Date(lastModified).toISOString()
                : null,
              detectedType,
              imageWidth: imageWidth ?? null,
              imageHeight: imageHeight ?? null,
              previewBytes: filePreviewBytes,
            }
          : null,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `smart-data-export-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setExportedFlash(true);
    setTimeout(() => setExportedFlash(false), 2000);
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Header */}
      <header className="bg-card border-b border-border flex-shrink-0">
        <div className="flex items-center justify-between px-4 h-12">
          {/* Brand */}
          <div className="flex items-center gap-2">
            <Bluetooth className="w-4 h-4 text-primary" />
            <span className="font-mono text-xs font-semibold tracking-widest text-foreground uppercase">
              Smart Data Extender
            </span>
            <span className="font-mono text-xs text-muted-foreground hidden sm:inline">
              | Data Extractor
            </span>
          </div>

          {/* Status pills + export */}
          <div className="flex items-center gap-3">
            <StatusPill
              label="BT"
              active={!!btConnected}
              activeColor="text-primary"
              dotColor={btConnected ? "bg-primary" : "bg-muted-foreground"}
            />
            <StatusPill
              label="GPS"
              active={!!gpsTracking}
              activeColor="text-accent"
              dotColor={gpsTracking ? "bg-accent" : "bg-muted-foreground"}
            />

            {/* Export All button */}
            <div className="relative" title={!hasData ? "No data yet" : ""}>
              <button
                type="button"
                data-ocid="header.export_all_button"
                onClick={handleExportAll}
                disabled={!hasData}
                className={[
                  "flex items-center gap-1.5 font-mono text-xs px-2.5 py-1 rounded-sm border transition-colors",
                  exportedFlash
                    ? "border-accent text-accent bg-accent/10"
                    : hasData
                      ? "border-primary/40 text-primary hover:bg-primary/10"
                      : "border-border/40 text-muted-foreground/40 cursor-not-allowed",
                ].join(" ")}
              >
                <Download className="w-3 h-3" />
                {exportedFlash ? "Exported!" : "Export All"}
              </button>
            </div>
          </div>
        </div>

        {/* Tab bar — 5 tabs, scrollable */}
        <nav
          className="flex border-t border-border overflow-x-auto"
          aria-label="App navigation"
        >
          <TabButton
            label="Bluetooth"
            icon={<Bluetooth className="w-3 h-3" />}
            active={activeTab === "bluetooth"}
            accentColor={TAB_ACCENT.bluetooth}
            onClick={() => onTabChange("bluetooth")}
            dataOcid="nav.bluetooth_tab"
          />
          <TabButton
            label="GPS"
            icon={<MapPin className="w-3 h-3" />}
            active={activeTab === "gps"}
            accentColor={TAB_ACCENT.gps}
            onClick={() => onTabChange("gps")}
            dataOcid="nav.gps_tab"
          />
          <TabButton
            label="File Upload"
            icon={<HardDrive className="w-3 h-3" />}
            active={activeTab === "file-upload"}
            accentColor={TAB_ACCENT["file-upload"]}
            onClick={() => onTabChange("file-upload")}
            dataOcid="nav.file_upload_tab"
          />
          <TabButton
            label="Phone Sensors"
            icon={<Activity className="w-3 h-3" />}
            active={activeTab === "sensors"}
            accentColor={TAB_ACCENT.sensors}
            onClick={() => onTabChange("sensors")}
            dataOcid="nav.sensors_tab"
          />
          <TabButton
            label="Fitness"
            icon={<Heart className="w-3 h-3" />}
            active={activeTab === "fitness"}
            accentColor={TAB_ACCENT.fitness}
            onClick={() => onTabChange("fitness")}
            dataOcid="nav.fitness_tab"
          />
          <TabButton
            label="Data Availability"
            icon={<Info className="w-3 h-3" />}
            active={activeTab === "data-availability"}
            accentColor={TAB_ACCENT["data-availability"]}
            onClick={() => onTabChange("data-availability")}
            dataOcid="nav.data_availability_tab"
          />
        </nav>
      </header>

      {/* Main content */}
      <main className="flex-1 overflow-auto">{children}</main>

      {/* Footer */}
      <footer className="bg-card border-t border-border px-4 py-2 flex-shrink-0">
        <p className="font-mono text-xs text-muted-foreground text-center">
          © {new Date().getFullYear()}.{" "}
          <a
            href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(typeof window !== "undefined" ? window.location.hostname : "")}`}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-accent transition-colors"
          >
            Built with love using caffeine.ai
          </a>
        </p>
      </footer>
    </div>
  );
}

// ─── Internal sub-components ────────────────────────────────────────────────────

interface TabButtonProps {
  label: string;
  icon: React.ReactNode;
  active: boolean;
  accentColor: string;
  onClick: () => void;
  dataOcid: string;
}

function TabButton({
  label,
  icon,
  active,
  accentColor,
  onClick,
  dataOcid,
}: TabButtonProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      data-ocid={dataOcid}
      style={
        active ? { borderBottomColor: accentColor, color: accentColor } : {}
      }
      className={[
        "flex items-center gap-1 flex-shrink-0 px-3 py-2 font-mono text-[10px] tracking-wider uppercase transition-colors border-b-2",
        active
          ? "bg-muted/20"
          : "border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/30",
      ].join(" ")}
    >
      {icon}
      {label}
    </button>
  );
}

interface StatusPillProps {
  label: string;
  active: boolean;
  activeColor: string;
  dotColor: string;
}

function StatusPill({ label, active, activeColor, dotColor }: StatusPillProps) {
  return (
    <div className="flex items-center gap-1.5">
      <span
        className={`status-indicator ${dotColor} ${active ? "animate-pulse" : "opacity-40"}`}
      />
      <span
        className={`font-mono text-xs tracking-widest ${active ? activeColor : "text-muted-foreground opacity-60"}`}
      >
        {label}
      </span>
    </div>
  );
}
