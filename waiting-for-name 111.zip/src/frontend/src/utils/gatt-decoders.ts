/**
 * GATT characteristic decoders for standard Bluetooth fitness profiles.
 * All parsers are null-safe and handle short/malformed DataView gracefully.
 */

// ─── Heart Rate Service (0x180D) ───────────────────────────────────────────────

export interface HeartRateData {
  bpm: number;
  /** true/false = contact detected/not detected; null = not supported */
  sensorContact: boolean | null;
  /** kJ, only present when Energy Expended flag is set */
  energyExpended: number | null;
  /** RR intervals in ms */
  rrIntervals: number[];
}

/**
 * Parse Heart Rate Measurement characteristic (0x2A37).
 * Flags byte layout:
 *   Bit 0: 0 = BPM is uint8, 1 = BPM is uint16
 *   Bit 1-2: Sensor Contact Status
 *   Bit 3: Energy Expended present
 *   Bit 4: RR-Interval present
 */
export function parseHeartRate(dv: DataView): HeartRateData | null {
  if (dv.byteLength < 2) return null;
  try {
    const flags = dv.getUint8(0);
    const is16bit = (flags & 0x01) !== 0;
    const contactSupported = (flags & 0x04) !== 0;
    const contactDetected = (flags & 0x02) !== 0;
    const energyPresent = (flags & 0x08) !== 0;
    const rrPresent = (flags & 0x10) !== 0;

    let offset = 1;
    let bpm: number;
    if (is16bit) {
      if (dv.byteLength < 3) return null;
      bpm = dv.getUint16(offset, true);
      offset += 2;
    } else {
      bpm = dv.getUint8(offset);
      offset += 1;
    }

    let energyExpended: number | null = null;
    if (energyPresent) {
      if (dv.byteLength >= offset + 2) {
        energyExpended = dv.getUint16(offset, true);
        offset += 2;
      }
    }

    const rrIntervals: number[] = [];
    if (rrPresent) {
      while (offset + 1 < dv.byteLength) {
        // RR interval in 1/1024 s units → convert to ms
        const raw = dv.getUint16(offset, true);
        rrIntervals.push(Math.round((raw / 1024) * 1000));
        offset += 2;
      }
    }

    return {
      bpm,
      sensorContact: contactSupported ? contactDetected : null,
      energyExpended,
      rrIntervals,
    };
  } catch {
    return null;
  }
}

// ─── Running Speed & Cadence Service (0x1814) ─────────────────────────────────

export interface RscData {
  /** Instantaneous speed in m/s */
  speed: number;
  /** Steps per minute */
  cadence: number;
  /** Stride length in meters, null if not present */
  strideLength: number | null;
  /** Total distance in meters, null if not present */
  totalDistance: number | null;
  isRunning: boolean;
}

/**
 * Parse RSC Measurement characteristic (0x2A53).
 * Flags byte:
 *   Bit 0: Instantaneous Stride Length present
 *   Bit 1: Total Distance present
 *   Bit 2: 0 = Walking, 1 = Running
 *
 * Speed: uint16 @ 1/256 m/s resolution
 * Cadence: uint8 steps/min
 * Stride Length: uint16 @ 1/100 m resolution (optional)
 * Total Distance: uint32 @ 1/10 m resolution (optional)
 */
export function parseRscMeasurement(dv: DataView): RscData | null {
  if (dv.byteLength < 4) return null;
  try {
    const flags = dv.getUint8(0);
    const stridePresent = (flags & 0x01) !== 0;
    const distancePresent = (flags & 0x02) !== 0;
    const isRunning = (flags & 0x04) !== 0;

    const speed = dv.getUint16(1, true) / 256;
    const cadence = dv.getUint8(3);
    let offset = 4;

    let strideLength: number | null = null;
    if (stridePresent) {
      if (dv.byteLength >= offset + 2) {
        strideLength = dv.getUint16(offset, true) / 100;
        offset += 2;
      }
    }

    let totalDistance: number | null = null;
    if (distancePresent) {
      if (dv.byteLength >= offset + 4) {
        totalDistance = dv.getUint32(offset, true) / 10;
      }
    }

    return { speed, cadence, strideLength, totalDistance, isRunning };
  } catch {
    return null;
  }
}

// ─── Cycling Speed & Cadence Service (0x1816) ─────────────────────────────────

export interface CscData {
  /** Cumulative wheel revolutions, null if not present */
  wheelRevolutions: number | null;
  /** Last wheel event time in 1/1024 s resolution, null if not present */
  wheelEventTime: number | null;
  /** Cumulative crank revolutions, null if not present */
  crankRevolutions: number | null;
  /** Last crank event time in 1/1024 s resolution, null if not present */
  crankEventTime: number | null;
}

/**
 * Parse CSC Measurement characteristic (0x2A5B).
 * Flags byte:
 *   Bit 0: Wheel Revolution Data present
 *   Bit 1: Crank Revolution Data present
 *
 * Wheel Revolutions: uint32
 * Wheel Event Time: uint16 (1/1024 s)
 * Crank Revolutions: uint16
 * Crank Event Time: uint16 (1/1024 s)
 */
export function parseCscMeasurement(dv: DataView): CscData | null {
  if (dv.byteLength < 1) return null;
  try {
    const flags = dv.getUint8(0);
    const wheelPresent = (flags & 0x01) !== 0;
    const crankPresent = (flags & 0x02) !== 0;
    let offset = 1;

    let wheelRevolutions: number | null = null;
    let wheelEventTime: number | null = null;
    if (wheelPresent) {
      if (dv.byteLength >= offset + 6) {
        wheelRevolutions = dv.getUint32(offset, true);
        offset += 4;
        wheelEventTime = dv.getUint16(offset, true);
        offset += 2;
      }
    }

    let crankRevolutions: number | null = null;
    let crankEventTime: number | null = null;
    if (crankPresent) {
      if (dv.byteLength >= offset + 4) {
        crankRevolutions = dv.getUint16(offset, true);
        offset += 2;
        crankEventTime = dv.getUint16(offset, true);
      }
    }

    return {
      wheelRevolutions,
      wheelEventTime,
      crankRevolutions,
      crankEventTime,
    };
  } catch {
    return null;
  }
}

// ─── Battery Service (0x180F) ─────────────────────────────────────────────────

export interface BatteryData {
  percent: number;
}

/**
 * Parse Battery Level characteristic (0x2A19).
 * Single uint8 value, 0–100.
 */
export function parseBatteryLevel(dv: DataView): BatteryData | null {
  if (dv.byteLength < 1) return null;
  try {
    return { percent: Math.min(100, Math.max(0, dv.getUint8(0))) };
  } catch {
    return null;
  }
}

// ─── Device Information Service (0x180A) ──────────────────────────────────────

/**
 * Decode a Device Information string characteristic (e.g. manufacturer name,
 * model number, firmware/hardware revision) from UTF-8 bytes.
 */
export function parseDeviceInfoString(dv: DataView): string | null {
  if (dv.byteLength < 1) return null;
  try {
    const bytes = new Uint8Array(dv.buffer, dv.byteOffset, dv.byteLength);
    return new TextDecoder("utf-8").decode(bytes).trim() || null;
  } catch {
    return null;
  }
}

// ─── Body Sensor Location (0x2A38) ────────────────────────────────────────────

const SENSOR_LOCATIONS: Record<number, string> = {
  0: "Other",
  1: "Chest",
  2: "Wrist",
  3: "Finger",
  4: "Hand",
  5: "Ear Lobe",
  6: "Foot",
};

export function parseBodySensorLocation(dv: DataView): string | null {
  if (dv.byteLength < 1) return null;
  try {
    const code = dv.getUint8(0);
    return SENSOR_LOCATIONS[code] ?? `Unknown (${code})`;
  } catch {
    return null;
  }
}
