import type { HexDumpRow } from "@/types";

/**
 * Format a single byte as two-digit uppercase hex, e.g. 0x0F -> "0F"
 */
export function formatHex(byte: number): string {
  return (byte & 0xff).toString(16).toUpperCase().padStart(2, "0");
}

/**
 * Format a single byte as 8-bit binary string, e.g. 5 -> "00000101"
 */
export function formatBinary(byte: number): string {
  return (byte & 0xff).toString(2).padStart(8, "0");
}

/**
 * Format offset as 8-digit zero-padded hex
 */
export function formatOffset(offset: number): string {
  return offset.toString(16).toUpperCase().padStart(8, "0");
}

/**
 * Build a full hex-dump row structure from a Uint8Array.
 * Groups of 16 bytes per row (standard hex editor layout).
 */
export function bytesToHexDump(
  data: Uint8Array,
  bytesPerRow = 16,
): HexDumpRow[] {
  const rows: HexDumpRow[] = [];
  for (let offset = 0; offset < data.length; offset += bytesPerRow) {
    const slice = Array.from(data.slice(offset, offset + bytesPerRow));
    rows.push({
      offset,
      bytes: slice,
      hex: slice.map(formatHex),
      decimal: slice.map((b) => b),
      binary: slice.map(formatBinary),
    });
  }
  return rows;
}

/**
 * Attempt to render bytes as ASCII; replace non-printable chars with '.'
 */
export function bytesToAscii(bytes: number[]): string {
  return bytes
    .map((b) => (b >= 0x20 && b < 0x7f ? String.fromCharCode(b) : "."))
    .join("");
}

/**
 * Human-readable GATT UUID resolver for common UUIDs
 */
const KNOWN_UUIDS: Record<string, string> = {
  "0000180a-0000-1000-8000-00805f9b34fb": "Device Information",
  "0000180d-0000-1000-8000-00805f9b34fb": "Heart Rate",
  "00001805-0000-1000-8000-00805f9b34fb": "Current Time",
  "0000180f-0000-1000-8000-00805f9b34fb": "Battery",
  "00001810-0000-1000-8000-00805f9b34fb": "Blood Pressure",
  "00001816-0000-1000-8000-00805f9b34fb": "Cycling Speed",
  "00001818-0000-1000-8000-00805f9b34fb": "Cycling Power",
  "00001819-0000-1000-8000-00805f9b34fb": "Location & Navigation",
  "00002a19-0000-1000-8000-00805f9b34fb": "Battery Level",
  "00002a29-0000-1000-8000-00805f9b34fb": "Manufacturer Name",
  "00002a24-0000-1000-8000-00805f9b34fb": "Model Number",
  "00002a25-0000-1000-8000-00805f9b34fb": "Serial Number",
  "00002a27-0000-1000-8000-00805f9b34fb": "Hardware Revision",
  "00002a26-0000-1000-8000-00805f9b34fb": "Firmware Revision",
  "00002a37-0000-1000-8000-00805f9b34fb": "Heart Rate Measurement",
  "00002a6e-0000-1000-8000-00805f9b34fb": "Temperature",
  "00002a6f-0000-1000-8000-00805f9b34fb": "Humidity",
};

export function resolveUuidName(uuid: string): string | null {
  return KNOWN_UUIDS[uuid.toLowerCase()] ?? null;
}

/** UUIDs considered "smartwatch primary services" */
const SMARTWATCH_SERVICE_UUIDS = new Set([
  "0000180d-0000-1000-8000-00805f9b34fb", // heart_rate
  "00001805-0000-1000-8000-00805f9b34fb", // current_time
  "0000180f-0000-1000-8000-00805f9b34fb", // battery
]);

/** Detect device type from name keywords or from advertised service UUIDs */
export type DeviceType = "watch" | "phone" | "unknown";

export function detectDeviceType(
  name: string,
  serviceUuids?: string[],
): DeviceType {
  // UUID-based heuristic first (most reliable)
  if (serviceUuids?.some((u) => SMARTWATCH_SERVICE_UUIDS.has(u.toLowerCase())))
    return "watch";

  const n = name.toLowerCase();
  if (
    n.includes("watch") ||
    n.includes("band") ||
    n.includes("fit") ||
    n.includes("gear") ||
    n.includes("versa") ||
    n.includes("sense") ||
    n.includes("ionic") ||
    n.includes("fenix") ||
    n.includes("vivoactive")
  )
    return "watch";
  if (
    n.includes("phone") ||
    n.includes("galaxy") ||
    n.includes("pixel") ||
    n.includes("iphone") ||
    n.includes("oneplus") ||
    n.includes("redmi") ||
    n.includes("xiaomi") ||
    n.includes("poco") ||
    n.includes("moto") ||
    n.includes("nokia")
  )
    return "phone";
  return "unknown";
}

export const DEVICE_TYPE_LABELS: Record<DeviceType, string> = {
  watch: "⌚ Watch",
  phone: "📱 Phone",
  unknown: "BLE Device",
};

/** Returns true if a service UUID belongs to the smartwatch-specific set */
export function isWatchService(uuid: string): boolean {
  return SMARTWATCH_SERVICE_UUIDS.has(uuid.toLowerCase());
}

/**
 * Format RSSI value with signal quality label
 */
export function formatRssi(rssi: number | null): string {
  if (rssi === null) return "N/A";
  if (rssi >= -50) return `${rssi} dBm (Excellent)`;
  if (rssi >= -70) return `${rssi} dBm (Good)`;
  if (rssi >= -80) return `${rssi} dBm (Fair)`;
  return `${rssi} dBm (Poor)`;
}

/**
 * Format timestamp as HH:MM:SS.mmm
 */
export function formatTimestampMs(ts: number): string {
  const d = new Date(ts);
  const hh = d.getHours().toString().padStart(2, "0");
  const mm = d.getMinutes().toString().padStart(2, "0");
  const ss = d.getSeconds().toString().padStart(2, "0");
  const ms = d.getMilliseconds().toString().padStart(3, "0");
  return `${hh}:${mm}:${ss}.${ms}`;
}

/**
 * Format timestamp as HH:MM:SS (local)
 */
export function formatTimestamp(ts: number): string {
  const d = new Date(ts);
  const hh = d.getHours().toString().padStart(2, "0");
  const mm = d.getMinutes().toString().padStart(2, "0");
  const ss = d.getSeconds().toString().padStart(2, "0");
  return `${hh}:${mm}:${ss}`;
}

/**
 * Speed color class based on km/h
 */
export function speedColorClass(speedKmh: number): string {
  if (speedKmh < 5) return "text-[oklch(0.72_0.18_145)]";
  if (speedKmh < 60) return "text-[oklch(0.78_0.17_85)]";
  return "text-destructive";
}
