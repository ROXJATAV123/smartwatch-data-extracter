// Removed — was only used by simulated panels
export {};
